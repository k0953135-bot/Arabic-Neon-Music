import React, { useState, useRef } from 'react';
import {
  VisualizerSettings,
  VisualizerStyle,
  BackgroundTheme,
  CenterFrameShape,
  ParticleMode,
  SecondaryWaveStyle,
  VisualizerLayer,
  CanvasBlendMode,
  BLEND_MODE_OPTIONS,
  TitleHideMode,
  COLOR_PALETTES,
  Palette,
  DEFAULT_SETTINGS,
  PRESET_WALLPAPERS,
} from '../types';
import {
  X,
  Check,
  Sliders,
  Sparkles,
  Activity,
  Layers,
  Palette as PaletteIcon,
  RotateCcw,
  Maximize2,
  Waves,
  Disc3,
  Orbit,
  Radio,
  Zap,
  Grid,
  Sun,
  Flame,
  Gauge,
  Music,
  Image as ImageIcon,
  Type,
  Crown,
  Feather,
  Upload,
  Trash2,
  Plus,
  Eye,
  EyeOff,
  Copy,
  ArrowUp,
  ArrowDown,
  Lock,
  Unlock,
  Move,
  ZoomIn,
  RotateCw,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: VisualizerSettings;
  onUpdateSettings: (newSettings: Partial<VisualizerSettings>) => void;
  currentPalette: Palette;
  onSelectPalette: (palette: Palette) => void;
}

type TabType =
  | 'emblems'
  | 'layers'
  | 'images'
  | 'texts'
  | 'shapes'
  | 'geometry'
  | 'audio'
  | 'lighting'
  | 'colors'
  | 'playback';

// Preset decorative SVG images encoded as data URIs
const PRESET_LAYER_GRAPHICS = [
  {
    name: 'هالة نيون دائرية',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><circle cx="100" cy="100" r="80" fill="none" stroke="%2300E5FF" stroke-width="6" stroke-dasharray="15 8" filter="drop-shadow(0 0 8px %2300E5FF)"/><circle cx="100" cy="100" r="92" fill="none" stroke="%239C27B0" stroke-width="2" opacity="0.7"/></svg>',
  },
  {
    name: 'شعار نجمي مشع',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><polygon points="100,10 125,75 195,75 138,115 160,185 100,140 40,185 62,115 5,75 75,75" fill="none" stroke="%23FFD700" stroke-width="4" filter="drop-shadow(0 0 10px %23FF9100)"/></svg>',
  },
  {
    name: 'درع سداسي نيون',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><polygon points="100,20 170,60 170,140 100,180 30,140 30,60" fill="none" stroke="%2300E676" stroke-width="4" stroke-dasharray="25 6" filter="drop-shadow(0 0 8px %2300E676)"/></svg>',
  },
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  currentPalette,
  onSelectPalette,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('emblems');
  const bgFileInputRef = useRef<HTMLInputElement | null>(null);
  const centerImgFileInputRef = useRef<HTMLInputElement | null>(null);
  const layerFileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const stylesList: {
    id: VisualizerStyle;
    label: string;
    desc: string;
    icon: React.ReactNode;
  }[] = [
    {
      id: 'radial',
      label: 'حلقة Avee الدائرية',
      desc: 'حلقة ترددات متوهجة تشع 360 درجة مع الشعار والتاج',
      icon: <Disc3 className="w-5 h-5" />,
    },
    {
      id: 'mirror',
      label: 'متناظر نيون',
      desc: 'تمدد علوي وسفلي متطابق مع كبسولات نيون',
      icon: <Layers className="w-5 h-5" />,
    },
    {
      id: 'bars',
      label: 'مدرج ترددات',
      desc: 'مدرج كلاسيكي صاعد مع مؤشرات القمة الحية',
      icon: <Activity className="w-5 h-5" />,
    },
    {
      id: 'wave',
      label: 'موجة متصلة',
      desc: 'منحنى جيبي ناعم ولامع بتدرج متدفق',
      icon: <Waves className="w-5 h-5" />,
    },
    {
      id: 'spiral',
      label: 'دوامة كونية',
      desc: 'دوامة لوغاريتمية ملتفة مع حركة جزيئات حلزونية',
      icon: <Orbit className="w-5 h-5" />,
    },
    {
      id: 'oscilloscope',
      label: 'راسم الذبذبات',
      desc: 'شاشة أوسيلوسكوب بصرية متزامنة مع نبضات الكهرباء',
      icon: <Radio className="w-5 h-5" />,
    },
    {
      id: 'starburst',
      label: 'أشعة النجوم',
      desc: 'أشعة نجمية حادة تنفجر من المركز مع ضربات الباس',
      icon: <Sparkles className="w-5 h-5" />,
    },
    {
      id: 'particles',
      label: 'سديم الجسيمات',
      desc: 'جسيمات نيون مدارية تسبح وتتجاذب مع الترددات',
      icon: <Zap className="w-5 h-5" />,
    },
    {
      id: 'cyber_grid',
      label: 'شبكة سايبربانك',
      desc: 'أفق ثلاثي الأبعاد بأسلوب شبكة ريترو مستقبلية',
      icon: <Grid className="w-5 h-5" />,
    },
    {
      id: 'capsules',
      label: 'كبسولات عائمة',
      desc: 'كتل كبسولية ناعمة ترقص بانسيابية وتوازن',
      icon: <Sun className="w-5 h-5" />,
    },
  ];

  const frameShapes: { id: CenterFrameShape; label: string; desc: string }[] = [
    { id: 'circle', label: 'دائرة نيون كلاسيكية', desc: 'حلقة نقية تدور حول الصورة المركزية' },
    { id: 'spiky_ring', label: 'حلقة شائكة (Avee Trap)', desc: 'أشواك مدببة تشع حول الشعار (مثل صورة EGO)' },
    { id: 'keyhole', label: 'شكل القفل (Keyhole)', desc: 'دائرة ممتدة ببروز نيون أنيق في الأسفل' },
    { id: 'hexagon', label: 'سداسي مضلع إلكتروني', desc: 'إطار هندسي مستقبلي مشع بالحواف الحادة' },
    { id: 'double_ring', label: 'حلقة نيون مزدوجة', desc: 'حلقتان تدوران في اتجاهين متعاكسين' },
  ];

  const activeColor =
    settings.colorMode === 'custom' ? settings.customColorOne : currentPalette.colorOne;
  const secondaryColor =
    settings.colorMode === 'custom' ? settings.customColorTwo : currentPalette.colorTwo;

  const handleResetToDefault = () => {
    onUpdateSettings(DEFAULT_SETTINGS);
  };

  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      onUpdateSettings({ backgroundImageUrl: url });
    }
  };

  const handleCenterImgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      onUpdateSettings({ waveCenterImageUrl: url });
    }
  };

  const handleAddImageLayerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      const newLayer: VisualizerLayer = {
        id: `layer_${Date.now()}`,
        name: `طبقة صورة ${settings.layers.length + 1}`,
        type: 'image',
        imageUrl: url,
        x: 0,
        y: 0,
        scale: 1.0,
        opacity: 0.9,
        rotation: 0,
        blendMode: 'screen',
        audioReactive: true,
        visible: true,
      };
      onUpdateSettings({ layers: [...settings.layers, newLayer] });
    }
  };

  const handleAddTextLayer = () => {
    const newLayer: VisualizerLayer = {
      id: `layer_${Date.now()}`,
      name: `نص مخصص ${settings.layers.length + 1}`,
      type: 'text',
      text: 'EGO_MUSIC',
      textColor: activeColor,
      x: 0,
      y: -25,
      scale: 1.0,
      opacity: 1.0,
      rotation: 0,
      blendMode: 'screen',
      audioReactive: true,
      visible: true,
    };
    onUpdateSettings({ layers: [...settings.layers, newLayer] });
  };

  const handleAddPresetLayer = (preset: { name: string; url: string }) => {
    const newLayer: VisualizerLayer = {
      id: `layer_${Date.now()}`,
      name: preset.name,
      type: 'image',
      imageUrl: preset.url,
      x: 0,
      y: 0,
      scale: 1.1,
      opacity: 0.85,
      rotation: 0,
      blendMode: 'screen',
      audioReactive: true,
      visible: true,
    };
    onUpdateSettings({ layers: [...settings.layers, newLayer] });
  };

  const handleUpdateLayer = (id: string, updates: Partial<VisualizerLayer>) => {
    const updated = settings.layers.map((layer) =>
      layer.id === id ? { ...layer, ...updates } : layer
    );
    onUpdateSettings({ layers: updated });
  };

  const handleDeleteLayer = (id: string) => {
    onUpdateSettings({ layers: settings.layers.filter((l) => l.id !== id) });
  };

  const handleDuplicateLayer = (layer: VisualizerLayer) => {
    const duplicated: VisualizerLayer = {
      ...layer,
      id: `layer_${Date.now()}`,
      name: `${layer.name} (نسخة)`,
      x: Math.min(90, layer.x + 5),
      y: Math.min(90, layer.y + 5),
    };
    onUpdateSettings({ layers: [...settings.layers, duplicated] });
  };

  const handleMoveLayer = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= settings.layers.length) return;
    const newLayers = [...settings.layers];
    const temp = newLayers[index];
    newLayers[index] = newLayers[targetIndex];
    newLayers[targetIndex] = temp;
    onUpdateSettings({ layers: newLayers });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md transition-opacity">
      <div
        className="w-full max-w-2xl bg-[#121520] border border-white/10 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in slide-in-from-bottom-6 duration-200"
        dir="rtl"
      >
        {/* Hidden File Inputs */}
        <input
          ref={bgFileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleBgUpload}
        />
        <input
          ref={centerImgFileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleCenterImgUpload}
        />
        <input
          ref={layerFileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleAddImageLayerUpload}
        />

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#151926]">
          <div className="flex items-center gap-3">
            <div
              className="p-2.5 rounded-2xl shadow-sm"
              style={{ backgroundColor: `${activeColor}20`, color: activeColor }}
            >
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white">إعدادات وموجات Avee الشاملة</h2>
              <p className="text-xs text-white/50">تخصيص الأجنحة، التاج، الصور، الطبقات اللانهائية، والنصوص</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-4 py-2 bg-[#0E1019] border-b border-white/5 overflow-x-auto custom-scrollbar shrink-0">
          {[
            { id: 'emblems', label: 'الأجنحة والتاج والشكل', icon: <Crown className="w-4 h-4" /> },
            { id: 'layers', label: `نظام الطبقات (${settings.layers.length})`, icon: <Layers className="w-4 h-4" /> },
            { id: 'images', label: 'الخلفية والشعار والاهتزاز', icon: <ImageIcon className="w-4 h-4" /> },
            { id: 'texts', label: 'النصوص وإخفاء الأزرار', icon: <Type className="w-4 h-4" /> },
            { id: 'shapes', label: 'أنماط الموجات والمزج', icon: <Waves className="w-4 h-4" /> },
            { id: 'geometry', label: 'الأبعاد والحركة', icon: <Maximize2 className="w-4 h-4" /> },
            { id: 'audio', label: 'الاستجابة والباس', icon: <Activity className="w-4 h-4" /> },
            { id: 'lighting', label: 'الإضاءة والبوكيه', icon: <Sparkles className="w-4 h-4" /> },
            { id: 'colors', label: 'الألوان المخصصة', icon: <PaletteIcon className="w-4 h-4" /> },
            { id: 'playback', label: 'السرعة والتلاشي', icon: <Gauge className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'text-black shadow-lg'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
                style={
                  isActive
                    ? {
                        background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                      }
                    : {}
                }
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body / Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar text-right">
          {/* TAB: EMBLEMS & ACCESSORIES */}
          {activeTab === 'emblems' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Crown className="w-4 h-4" style={{ color: activeColor }} />
                  ملحقات وإكسسوارات الموجات الملكية (Avee Emblems)
                </h3>
                <p className="text-xs text-white/50">
                  إضافة الأجنحة النيونية المشعة، التاج الملكي المرصع، وتشكيل إطار الشعار
                </p>
              </div>

              {/* Angel Wings Toggle & Spread */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Feather className="w-4 h-4 text-cyan-400" />
                    <div>
                      <span className="text-sm font-bold text-white block">
                        أجنحة النيون المشعة (Angel Wings)
                      </span>
                      <span className="text-xs text-white/40">
                        أجنحة فيكتور نيونية ترفرف وتتسع بنعومة على جانبي الدائرة
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => onUpdateSettings({ showAngelWings: !settings.showAngelWings })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      settings.showAngelWings ? 'bg-cyan-400' : 'bg-white/20'
                    }`}
                    style={{ backgroundColor: settings.showAngelWings ? activeColor : undefined }}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                        settings.showAngelWings ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                      }`}
                    />
                  </button>
                </div>

                {settings.showAngelWings && (
                  <div className="pt-2 border-t border-white/5 space-y-2 animate-in fade-in duration-150">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-white/70">مدى امتداد الأجنحة</span>
                      <span className="font-mono text-white/90">{settings.wingsSpread.toFixed(1)}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="1.8"
                      step="0.1"
                      value={settings.wingsSpread}
                      onChange={(e) => onUpdateSettings({ wingsSpread: Number(e.target.value) })}
                      className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                      style={{ accentColor: activeColor }}
                    />
                  </div>
                )}
              </div>

              {/* Royal Crown Toggle & Scale */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Crown className="w-4 h-4 text-yellow-400" />
                    <div>
                      <span className="text-sm font-bold text-white block">
                        التاج الملكي المشع (Royal Crown)
                      </span>
                      <span className="text-xs text-white/40">
                        تاج مرصع بالجواهر النيونية فوق الشعار والدائرة
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => onUpdateSettings({ showRoyalCrown: !settings.showRoyalCrown })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      settings.showRoyalCrown ? 'bg-cyan-400' : 'bg-white/20'
                    }`}
                    style={{ backgroundColor: settings.showRoyalCrown ? activeColor : undefined }}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                        settings.showRoyalCrown ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                      }`}
                    />
                  </button>
                </div>

                {settings.showRoyalCrown && (
                  <div className="pt-2 border-t border-white/5 space-y-2 animate-in fade-in duration-150">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-white/70">حجم التاج الملكي</span>
                      <span className="font-mono text-white/90">{settings.crownScale.toFixed(1)}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.6"
                      max="1.5"
                      step="0.1"
                      value={settings.crownScale}
                      onChange={(e) => onUpdateSettings({ crownScale: Number(e.target.value) })}
                      className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                      style={{ accentColor: activeColor }}
                    />
                  </div>
                )}
              </div>

              {/* Center Frame Shape Selection */}
              <div>
                <label className="text-xs font-bold text-white/80 block mb-2">
                  شكل إطار وتصميم مركز الموجات:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {frameShapes.map((shape) => {
                    const isSelected = settings.centerFrameShape === shape.id;
                    return (
                      <button
                        key={shape.id}
                        onClick={() => onUpdateSettings({ centerFrameShape: shape.id })}
                        className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                          isSelected
                            ? 'border-transparent shadow-lg'
                            : 'border-white/10 bg-[#151926] hover:bg-[#151926]/80'
                        }`}
                        style={
                          isSelected
                            ? {
                                backgroundColor: `${activeColor}18`,
                                borderColor: activeColor,
                              }
                            : {}
                        }
                      >
                        <span
                          className="text-xs font-bold block"
                          style={{ color: isSelected ? activeColor : '#FFF' }}
                        >
                          {shape.label}
                        </span>
                        <span className="text-[10px] text-white/40 block mt-0.5">{shape.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Inner Equalizer Toggle */}
              <div className="flex items-center justify-between p-3.5 bg-[#151926] rounded-2xl border border-white/5">
                <div>
                  <span className="text-sm font-semibold text-white/90 block">
                    مدرج ترددات مصغر في قلب الشعار
                  </span>
                  <span className="text-xs text-white/40">
                    أعمدة مضيئة ترقص داخل الدائرة المركزية (مثل صورة الفراشة والتاج)
                  </span>
                </div>
                <button
                  onClick={() => onUpdateSettings({ showInnerEqualizer: !settings.showInnerEqualizer })}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                    settings.showInnerEqualizer ? 'bg-cyan-400' : 'bg-white/20'
                  }`}
                  style={{ backgroundColor: settings.showInnerEqualizer ? activeColor : undefined }}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                      settings.showInnerEqualizer ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                    }`}
                  />
                </button>
              </div>
            </div>
          )}

          {/* TAB: INFINITE LAYER SYSTEM (نظام الطبقات غير المحدود) */}
          {activeTab === 'layers' && (
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Layers className="w-4 h-4" style={{ color: activeColor }} />
                    استوديو الطبقات اللانهائي (Infinite Layer Studio)
                  </h3>
                  <p className="text-xs text-white/50">
                    إضافة طبقات صور ونصوص بعدد غير محدود مع أوضاع المزج (شاشة، تراكب، اختلاف، ضوء ساطع)
                  </p>
                </div>
                {/* Add Layer Actions */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    onClick={() => layerFileInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold text-black flex items-center gap-1 shadow-md cursor-pointer transition-all hover:brightness-110"
                    style={{
                      background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>صورة من جهازك</span>
                  </button>
                  <button
                    onClick={handleAddTextLayer}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/15 text-white flex items-center gap-1 border border-white/10 cursor-pointer"
                  >
                    <Type className="w-3.5 h-3.5 text-cyan-400" />
                    <span>طبقة نص</span>
                  </button>
                </div>
              </div>

              {/* Quick Preset Badges */}
              <div className="bg-[#151926]/60 p-3 rounded-2xl border border-white/5 space-y-2">
                <span className="text-[11px] font-bold text-white/70 block">
                  إضافة طبقة جاهزة بلمسة واحدة:
                </span>
                <div className="flex items-center gap-2 flex-wrap">
                  {PRESET_LAYER_GRAPHICS.map((preset) => (
                    <button
                      key={preset.name}
                      onClick={() => handleAddPresetLayer(preset)}
                      className="px-2.5 py-1 rounded-lg text-xs bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 flex items-center gap-1.5 cursor-pointer transition-all"
                    >
                      <Sparkles className="w-3 h-3 text-yellow-400" />
                      <span>{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Active Layers List */}
              {settings.layers.length === 0 ? (
                <div className="p-8 rounded-2xl bg-[#151926]/40 border border-dashed border-white/10 text-center space-y-3">
                  <Layers className="w-10 h-10 mx-auto text-white/20 animate-pulse" />
                  <p className="text-sm font-bold text-white/70">لا توجد طبقات مضافة حالياً</p>
                  <p className="text-xs text-white/40 max-w-sm mx-auto">
                    يمكنك رفع صورك الخاصة، إضافة شعارات، علامات مائية نيون، أو نصوص تتفاعل وتهتز مع الباس
                  </p>
                  <div className="flex justify-center gap-2 pt-2">
                    <button
                      onClick={() => layerFileInputRef.current?.click()}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-400 text-black cursor-pointer hover:bg-cyan-300 transition-colors"
                      style={{ backgroundColor: activeColor }}
                    >
                      إضافة أول طبقة صورة
                    </button>
                    <button
                      onClick={handleAddTextLayer}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-white/10 text-white border border-white/10 cursor-pointer"
                    >
                      إضافة طبقة نص
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {settings.layers.map((layer, idx) => (
                    <div
                      key={layer.id}
                      className="bg-[#151926] p-4 rounded-2xl border border-white/10 space-y-3.5 shadow-md"
                    >
                      {/* Layer Header Row */}
                      <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2.5">
                        <div className="flex items-center gap-2 min-w-0">
                          <button
                            onClick={() => handleUpdateLayer(layer.id, { visible: !layer.visible })}
                            className="p-1.5 rounded-lg text-white/70 hover:text-white bg-white/5 hover:bg-white/10 cursor-pointer transition-colors"
                            title={layer.visible ? 'إخفاء الطبقة' : 'إظهار الطبقة'}
                          >
                            {layer.visible ? (
                              <Eye className="w-4 h-4 text-emerald-400" />
                            ) : (
                              <EyeOff className="w-4 h-4 text-red-400" />
                            )}
                          </button>
                          {layer.type === 'text' ? (
                            <Type className="w-4 h-4 text-cyan-400 shrink-0" />
                          ) : (
                            <ImageIcon className="w-4 h-4 text-purple-400 shrink-0" />
                          )}
                          <input
                            type="text"
                            value={layer.name}
                            onChange={(e) => handleUpdateLayer(layer.id, { name: e.target.value })}
                            className="bg-transparent border-none text-xs font-bold text-white focus:outline-none truncate w-32 sm:w-48 hover:bg-white/5 px-1 py-0.5 rounded"
                          />
                        </div>

                        {/* Layer Actions: Reorder, Duplicate, Delete */}
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleMoveLayer(idx, 'up')}
                            disabled={idx === 0}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white disabled:opacity-20 cursor-pointer"
                            title="تحريك لأعلى"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleMoveLayer(idx, 'down')}
                            disabled={idx === settings.layers.length - 1}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white disabled:opacity-20 cursor-pointer"
                            title="تحريك لأسفل"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDuplicateLayer(layer)}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-cyan-400 cursor-pointer"
                            title="تكرار الطبقة"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteLayer(layer.id)}
                            className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 cursor-pointer"
                            title="حذف الطبقة"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Text content input if text layer */}
                      {layer.type === 'text' && (
                        <div className="space-y-1">
                          <label className="text-[11px] font-semibold text-white/70 block">
                            النص المكتوب في الطبقة:
                          </label>
                          <input
                            type="text"
                            value={layer.text || ''}
                            onChange={(e) => handleUpdateLayer(layer.id, { text: e.target.value })}
                            className="w-full px-3 py-1.5 bg-black/40 border border-white/10 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-cyan-400"
                            placeholder="اكتب النص هنا..."
                          />
                        </div>
                      )}

                      {/* BLEND MODE SELECTOR (أوضاع المزج) */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-bold text-white/80 block">
                          وضع المزج اللوني (Blend Mode):
                        </label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                          {BLEND_MODE_OPTIONS.map((mode) => {
                            const isSelected = layer.blendMode === mode.id;
                            return (
                              <button
                                key={mode.id}
                                onClick={() => handleUpdateLayer(layer.id, { blendMode: mode.id })}
                                className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                                  isSelected
                                    ? 'border-transparent text-black shadow-md'
                                    : 'border-white/10 bg-white/5 text-white/70 hover:bg-white/10'
                                }`}
                                style={
                                  isSelected
                                    ? {
                                        background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                                      }
                                    : {}
                                }
                                title={mode.desc}
                              >
                                {mode.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Layer Sliders: Scale, Opacity, Pan X, Pan Y, Rotation */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-white/60">الحجم والتكبير (Scale)</span>
                            <span className="font-mono text-white/90">
                              {Math.round(layer.scale * 100)}%
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0.2"
                            max="3.0"
                            step="0.05"
                            value={layer.scale}
                            onChange={(e) =>
                              handleUpdateLayer(layer.id, { scale: Number(e.target.value) })
                            }
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: activeColor }}
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-white/60">الشفافية (Opacity)</span>
                            <span className="font-mono text-white/90">
                              {Math.round(layer.opacity * 100)}%
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0.05"
                            max="1.0"
                            step="0.05"
                            value={layer.opacity}
                            onChange={(e) =>
                              handleUpdateLayer(layer.id, { opacity: Number(e.target.value) })
                            }
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: activeColor }}
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-white/60">الإزاحة الأفقية X (يمين / يسار)</span>
                            <span className="font-mono text-white/90">{layer.x}%</span>
                          </div>
                          <input
                            type="range"
                            min="-100"
                            max="100"
                            step="1"
                            value={layer.x}
                            onChange={(e) =>
                              handleUpdateLayer(layer.id, { x: Number(e.target.value) })
                            }
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: activeColor }}
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-white/60">الإزاحة العمودية Y (أعلى / أسفل)</span>
                            <span className="font-mono text-white/90">{layer.y}%</span>
                          </div>
                          <input
                            type="range"
                            min="-100"
                            max="100"
                            step="1"
                            value={layer.y}
                            onChange={(e) =>
                              handleUpdateLayer(layer.id, { y: Number(e.target.value) })
                            }
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: activeColor }}
                          />
                        </div>

                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-white/60">التدوير (Rotation)</span>
                            <span className="font-mono text-white/90">{layer.rotation}°</span>
                          </div>
                          <input
                            type="range"
                            min="0"
                            max="360"
                            step="5"
                            value={layer.rotation}
                            onChange={(e) =>
                              handleUpdateLayer(layer.id, { rotation: Number(e.target.value) })
                            }
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: activeColor }}
                          />
                        </div>

                        {/* Audio Reactive Toggle */}
                        <div className="flex items-center justify-between p-2 rounded-xl bg-black/20 border border-white/5">
                          <div className="flex items-center gap-1.5">
                            <Activity className="w-3.5 h-3.5 text-cyan-400" />
                            <span className="text-xs font-semibold text-white/80">
                              تفاعل واهتزاز مع الباس
                            </span>
                          </div>
                          <button
                            onClick={() =>
                              handleUpdateLayer(layer.id, { audioReactive: !layer.audioReactive })
                            }
                            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer ${
                              layer.audioReactive ? 'bg-cyan-400' : 'bg-white/20'
                            }`}
                            style={{ backgroundColor: layer.audioReactive ? activeColor : undefined }}
                          >
                            <span
                              className={`inline-block h-3.5 w-3.5 transform rounded-full bg-black transition-transform ${
                                layer.audioReactive ? 'translate-x-[-18px]' : 'translate-x-[-2px]'
                              }`}
                            />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Multi-Layer Secondary Waves Stacking */}
              <div className="pt-4 border-t border-white/10 space-y-3">
                <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-bold text-white block">
                        طبقة موجات إضافية متراكبة (موجات فوق بعض)
                      </span>
                      <span className="text-xs text-white/40">
                        إظهار مدرج طيف أفقي سفلي فوق شريط التقدم (مثل فيديو Avee الملكي)
                      </span>
                    </div>
                    <button
                      onClick={() =>
                        onUpdateSettings({ enableSecondaryWave: !settings.enableSecondaryWave })
                      }
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                        settings.enableSecondaryWave ? 'bg-cyan-400' : 'bg-white/20'
                      }`}
                      style={{ backgroundColor: settings.enableSecondaryWave ? activeColor : undefined }}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                          settings.enableSecondaryWave ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                        }`}
                      />
                    </button>
                  </div>

                  {settings.enableSecondaryWave && (
                    <div className="pt-3 border-t border-white/5 space-y-3 animate-in fade-in duration-150">
                      <label className="text-xs font-semibold text-white/80 block">
                        نوع الموجة الثانوية المتراكبة:
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'bottom_bars', label: 'مدرج أفقي سفلي' },
                          { id: 'mirror_bars', label: 'متناظر منقسم' },
                          { id: 'center_line', label: 'خط جيبي متدفق' },
                        ].map((item) => {
                          const isSelected = settings.secondaryWaveStyle === item.id;
                          return (
                            <button
                              key={item.id}
                              onClick={() =>
                                onUpdateSettings({ secondaryWaveStyle: item.id as SecondaryWaveStyle })
                              }
                              className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-transparent text-black shadow-md'
                                  : 'border-white/10 bg-white/5 text-white/70'
                              }`}
                              style={
                                isSelected
                                  ? {
                                      background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                                    }
                                  : {}
                              }
                            >
                              {item.label}
                            </button>
                          );
                        })}
                      </div>

                      <div className="space-y-1 pt-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/60">ارتفاع وحجم الموجة الإضافية</span>
                          <span className="font-mono text-white/90">
                            {settings.secondaryWaveHeight.toFixed(1)}x
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0.3"
                          max="1.5"
                          step="0.1"
                          value={settings.secondaryWaveHeight}
                          onChange={(e) =>
                            onUpdateSettings({ secondaryWaveHeight: Number(e.target.value) })
                          }
                          className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                          style={{ accentColor: activeColor }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB: IMAGES & WALLPAPER & AUDIO MOTION */}
          {activeTab === 'images' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-cyan-400" />
                  صورة الخلفية، موازنة الأبعاد، واهتزاز الباس
                </h3>
                <p className="text-xs text-white/50">
                  التحكم الكامل بالتكبير، التصغير، اليمين واليسار، وضع المزج، والتفاعل الحركي مع الباس
                </p>
              </div>

              {/* 1. Custom Background Wallpaper Controls */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-bold text-white block">
                      صورة خلفية الشاشة (Full Wallpaper)
                    </span>
                    <span className="text-xs text-white/40">
                      صورة خلفية كاملة تحت الموجات مع دعم التكبير والإزاحة
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {settings.backgroundImageUrl && (
                      <button
                        onClick={() => onUpdateSettings({ backgroundImageUrl: null })}
                        className="p-2 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors cursor-pointer"
                        title="إزالة الصورة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => bgFileInputRef.current?.click()}
                      className="px-3.5 py-2 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/15 text-white transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>{settings.backgroundImageUrl ? 'تغيير الصورة' : 'رفع صورة'}</span>
                    </button>
                  </div>
                </div>

                {/* Preset Wallpapers (8K Vocal Soundwaves Studio) */}
                <div className="space-y-2 pt-2 border-t border-white/5">
                  <span className="text-[11px] font-bold text-white/70 block">
                    خلفيات Avee المدمجة الجاهزة (8K Studio Artwork):
                  </span>
                  <div className="grid grid-cols-1 gap-2">
                    {PRESET_WALLPAPERS.map((wp) => {
                      const isSelected = settings.backgroundImageUrl === wp.url;
                      return (
                        <div
                          key={wp.id}
                          onClick={() => onUpdateSettings({ backgroundImageUrl: wp.url, backgroundBlur: 0, backgroundOpacity: 0.9 })}
                          className={`p-2.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${
                            isSelected
                              ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-500/10'
                              : 'border-white/10 bg-white/5 hover:bg-white/10'
                          }`}
                        >
                          <img
                            src={wp.url}
                            alt={wp.name}
                            referrerPolicy="no-referrer"
                            className="w-14 h-14 rounded-xl object-cover shrink-0 border border-white/10"
                          />
                          <div className="flex-1 min-w-0 text-right">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-white truncate">{wp.name}</span>
                              {isSelected && <Check className="w-4 h-4 text-cyan-400 shrink-0" />}
                            </div>
                            <p className="text-[10px] text-white/50 line-clamp-1 mt-0.5">{wp.desc}</p>
                            <span className="inline-block mt-1 text-[9px] px-2 py-0.5 rounded-full bg-cyan-400/10 text-cyan-300 font-mono">
                              {isSelected ? 'مفعلة كخلفية حالية' : 'انقر للتفعيل'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {settings.backgroundImageUrl && (
                  <div className="space-y-4 animate-in fade-in duration-150">
                    {/* Thumbnail preview */}
                    <div className="w-full h-28 rounded-xl overflow-hidden relative border border-white/10 group">
                      <img
                        src={settings.backgroundImageUrl}
                        alt="Background Preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => onUpdateSettings({ bgScale: 1.0, bgOffsetX: 0, bgOffsetY: 0 })}
                          className="px-3 py-1.5 rounded-lg bg-black/70 text-white text-xs font-bold border border-white/20"
                        >
                          إعادة ضبط الموضع للمنتصف
                        </button>
                      </div>
                    </div>

                    {/* SCALE / ZOOM (تكبير وتصغير) */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-white/80 font-bold flex items-center gap-1.5">
                          <ZoomIn className="w-3.5 h-3.5 text-cyan-400" />
                          التكبير والتصغير (Zoom & Scale):
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-white/90">
                            {Math.round((settings.bgScale || 1.0) * 100)}%
                          </span>
                          <button
                            onClick={() => onUpdateSettings({ bgScale: 1.0 })}
                            className="text-[10px] text-cyan-400 hover:underline cursor-pointer"
                          >
                            إعادة 100%
                          </button>
                        </div>
                      </div>
                      <input
                        type="range"
                        min="0.5"
                        max="2.5"
                        step="0.05"
                        value={settings.bgScale || 1.0}
                        onChange={(e) => onUpdateSettings({ bgScale: Number(e.target.value) })}
                        className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                        style={{ accentColor: activeColor }}
                      />
                    </div>

                    {/* PAN HORIZONTAL X (يمين ويسار) & PAN VERTICAL Y (أعلى وأسفل) */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/70">الموازنة الأفقية X (يمين / يسار):</span>
                          <span className="font-mono text-white/90">{settings.bgOffsetX || 0}%</span>
                        </div>
                        <input
                          type="range"
                          min="-100"
                          max="100"
                          step="1"
                          value={settings.bgOffsetX || 0}
                          onChange={(e) => onUpdateSettings({ bgOffsetX: Number(e.target.value) })}
                          className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                          style={{ accentColor: activeColor }}
                        />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/70">الموازنة العمودية Y (أعلى / أسفل):</span>
                          <span className="font-mono text-white/90">{settings.bgOffsetY || 0}%</span>
                        </div>
                        <input
                          type="range"
                          min="-100"
                          max="100"
                          step="1"
                          value={settings.bgOffsetY || 0}
                          onChange={(e) => onUpdateSettings({ bgOffsetY: Number(e.target.value) })}
                          className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                          style={{ accentColor: activeColor }}
                        />
                      </div>
                    </div>

                    {/* AUDIO MOTION: حركة واهتزاز الخلفية مع الباس */}
                    <div className="p-3.5 rounded-2xl bg-black/30 border border-white/5 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Activity className="w-4 h-4 text-pink-400" />
                          <div>
                            <span className="text-xs font-bold text-white block">
                              حركة واهتزاز الخلفية مع موجات الصوت (Bass Motion)
                            </span>
                            <span className="text-[10px] text-white/40">
                              جعل صورة الخلفية تنبض وتهتز حركياً مع ضربات الباس
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={() => onUpdateSettings({ bgAudioMotion: !settings.bgAudioMotion })}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                            settings.bgAudioMotion ? 'bg-cyan-400' : 'bg-white/20'
                          }`}
                          style={{ backgroundColor: settings.bgAudioMotion ? activeColor : undefined }}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                              settings.bgAudioMotion ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                            }`}
                          />
                        </button>
                      </div>

                      {settings.bgAudioMotion && (
                        <div className="pt-2 border-t border-white/5 space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-white/60">شدة اهتزاز الخلفية مع النبض</span>
                            <span className="font-mono text-white/90">
                              {(settings.bgMotionIntensity || 1.0).toFixed(1)}x
                            </span>
                          </div>
                          <input
                            type="range"
                            min="0.3"
                            max="2.5"
                            step="0.1"
                            value={settings.bgMotionIntensity || 1.0}
                            onChange={(e) =>
                              onUpdateSettings({ bgMotionIntensity: Number(e.target.value) })
                            }
                            className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            style={{ accentColor: activeColor }}
                          />
                        </div>
                      )}
                    </div>

                    {/* BACKGROUND BLEND MODE (وضع مزج الخلفية) */}
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-white/80 block">
                        وضع مزج الخلفية (Background Blend Mode):
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                        {BLEND_MODE_OPTIONS.map((mode) => {
                          const isSelected = settings.bgBlendMode === mode.id;
                          return (
                            <button
                              key={mode.id}
                              onClick={() => onUpdateSettings({ bgBlendMode: mode.id })}
                              className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                                isSelected
                                  ? 'border-transparent text-black shadow-md'
                                  : 'border-white/10 bg-white/5 text-white/70 hover:bg-white/10'
                              }`}
                              style={
                                isSelected
                                  ? {
                                      background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                                    }
                                  : {}
                              }
                              title={mode.desc}
                            >
                              {mode.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Blur & Opacity */}
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-white/60">ضبابية الخلفية (Blur)</span>
                          <span className="font-mono text-white/90">{settings.backgroundBlur}px</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="20"
                          step="1"
                          value={settings.backgroundBlur}
                          onChange={(e) => onUpdateSettings({ backgroundBlur: Number(e.target.value) })}
                          className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                          style={{ accentColor: activeColor }}
                        />
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-white/60">شفافية الصورة</span>
                          <span className="font-mono text-white/90">
                            {Math.round(settings.backgroundOpacity * 100)}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="1.0"
                          step="0.05"
                          value={settings.backgroundOpacity}
                          onChange={(e) =>
                            onUpdateSettings({ backgroundOpacity: Number(e.target.value) })
                          }
                          className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                          style={{ accentColor: activeColor }}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* 2. Custom Center Image on Waves (الشعار المركزي) */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-bold text-white block">
                      صورة وشعار قلب الموجات (Center Avatar)
                    </span>
                    <span className="text-xs text-white/40">
                      صورة دائرية أو لوجو القناة في مركز الدائرة (مثل شعار EGO و RC)
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {settings.waveCenterImageUrl && (
                      <button
                        onClick={() => onUpdateSettings({ waveCenterImageUrl: null })}
                        className="p-2 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors cursor-pointer"
                        title="إزالة الشعار"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => centerImgFileInputRef.current?.click()}
                      className="px-3.5 py-2 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/15 text-white transition-all flex items-center gap-1.5 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>{settings.waveCenterImageUrl ? 'تغيير الشعار' : 'رفع شعار / صورة'}</span>
                    </button>
                  </div>
                </div>

                {settings.waveCenterImageUrl && (
                  <div className="pt-2 border-t border-white/5 space-y-3 animate-in fade-in duration-150">
                    <div className="flex items-center gap-3">
                      <img
                        src={settings.waveCenterImageUrl}
                        alt="Center Preview"
                        className="w-12 h-12 rounded-full object-cover border-2"
                        style={{ borderColor: activeColor }}
                      />
                      <div className="flex-1 space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-white/60">حجم الشعار الدائري</span>
                          <span className="font-mono text-white/90">{settings.waveCenterImageSize}px</span>
                        </div>
                        <input
                          type="range"
                          min="40"
                          max="150"
                          step="5"
                          value={settings.waveCenterImageSize}
                          onChange={(e) =>
                            onUpdateSettings({ waveCenterImageSize: Number(e.target.value) })
                          }
                          className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                          style={{ accentColor: activeColor }}
                        />
                      </div>
                    </div>

                    {/* Center Image Blend Mode */}
                    <div className="space-y-1.5 pt-1">
                      <label className="text-[11px] font-bold text-white/80 block">
                        وضع مزج الشعار المركزي (Center Logo Blend):
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                        {BLEND_MODE_OPTIONS.slice(0, 4).map((mode) => {
                          const isSelected = settings.centerAvatarBlendMode === mode.id;
                          return (
                            <button
                              key={mode.id}
                              onClick={() => onUpdateSettings({ centerAvatarBlendMode: mode.id })}
                              className={`px-2 py-1 rounded-lg border text-[10px] font-bold transition-all cursor-pointer ${
                                isSelected ? 'bg-cyan-400 text-black border-transparent' : 'bg-white/5 text-white/70 border-white/10'
                              }`}
                              style={isSelected ? { backgroundColor: activeColor, color: '#000' } : {}}
                            >
                              {mode.label}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        onClick={() =>
                          onUpdateSettings({ waveCenterImageSpin: !settings.waveCenterImageSpin })
                        }
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                          settings.waveCenterImageSpin
                            ? 'border-transparent bg-white/20 text-white shadow-sm'
                            : 'border-white/10 bg-white/5 text-white/50'
                        }`}
                      >
                        {settings.waveCenterImageSpin ? 'دوران الفينيل: مفعل' : 'دوران الفينيل: معطل'}
                      </button>

                      <button
                        onClick={() =>
                          onUpdateSettings({ waveCenterImageBorder: !settings.waveCenterImageBorder })
                        }
                        className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                          settings.waveCenterImageBorder
                            ? 'border-transparent bg-white/20 text-white shadow-sm'
                            : 'border-white/10 bg-white/5 text-white/50'
                        }`}
                      >
                        {settings.waveCenterImageBorder ? 'إطار نيون مشع: مفعل' : 'إطار نيون: معطل'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB: TEXTS & WATERMARK & UI HIDING */}
          {activeTab === 'texts' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Type className="w-4 h-4 text-emerald-400" />
                  النصوص، أسماء الأغاني، والتحكم باختفاء الأزرار
                </h3>
                <p className="text-xs text-white/50">
                  تحديد سلوك اختفاء اسم الأغنية (مع البار السفلي أو دائماً)، وتثبيت الأزرار لمنع اختفائها
                </p>
              </div>

              {/* SONG TITLE HIDE MODE (طلب المستخدم: يختفي مع البار السفلي مع خيار إبقائه) */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center gap-2">
                  <Music className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-white block">
                    سلوك ظهور واختفاء اسم الأغنية (ألحان الفضاء الخ):
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    {
                      id: 'sync_with_bar',
                      label: 'يختفي مع البار السفلي',
                      desc: 'يختفي اسم الأغنية تلقائياً بعد عدة ثوانٍ مع أزرار التحكم',
                    },
                    {
                      id: 'always_visible',
                      label: 'إبقاء الاسم ظاهراً دائماً',
                      desc: 'يبقى اسم الأغنية والفنان ظاهراً حتى لو اختفت الأزرار',
                    },
                    {
                      id: 'hidden',
                      label: 'إخفاء الاسم نهائياً',
                      desc: 'عدم إظهار نص الأغنية على الشاشة',
                    },
                  ].map((item) => {
                    const isSelected = settings.titleHideMode === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() =>
                          onUpdateSettings({ titleHideMode: item.id as TitleHideMode })
                        }
                        className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                          isSelected
                            ? 'border-transparent shadow-lg text-black'
                            : 'border-white/10 bg-white/5 text-white/70 hover:bg-white/10'
                        }`}
                        style={
                          isSelected
                            ? {
                                background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                              }
                            : {}
                        }
                      >
                        <span className="text-xs font-black block">{item.label}</span>
                        <span
                          className={`text-[10px] block mt-0.5 ${
                            isSelected ? 'text-black/80' : 'text-white/40'
                          }`}
                        >
                          {item.desc}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* LOCK CONTROLS TOGGLE (حل مشكلة: بعض الاحيان الخيارات تختفي كلياً اريد تزبيطها) */}
              <div className="flex items-center justify-between p-4 bg-[#151926] rounded-2xl border border-white/5">
                <div className="flex items-center gap-2.5">
                  {settings.lockControlsVisible ? (
                    <Lock className="w-5 h-5 text-amber-400" />
                  ) : (
                    <Unlock className="w-5 h-5 text-white/50" />
                  )}
                  <div>
                    <span className="text-sm font-bold text-white block">
                      تثبيت أزرار وشاشات التحكم دائماً (Lock Controls)
                    </span>
                    <span className="text-xs text-white/40">
                      منع الاختفاء التلقائي للأزرار نهائياً لتبقى كل الخيارات ظاهرة أمامك طوال الوقت
                    </span>
                  </div>
                </div>
                <button
                  onClick={() =>
                    onUpdateSettings({ lockControlsVisible: !settings.lockControlsVisible })
                  }
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                    settings.lockControlsVisible ? 'bg-cyan-400' : 'bg-white/20'
                  }`}
                  style={{ backgroundColor: settings.lockControlsVisible ? activeColor : undefined }}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                      settings.lockControlsVisible ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                    }`}
                  />
                </button>
              </div>

              {/* TEXT BLEND MODE (أوضاع المزج للنصوص) */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-2">
                <label className="text-xs font-bold text-white/80 block">
                  وضع المزج اللوني للنصوص (Text Blend Mode):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {BLEND_MODE_OPTIONS.slice(0, 4).map((mode) => {
                    const isSelected = settings.textBlendMode === mode.id;
                    return (
                      <button
                        key={mode.id}
                        onClick={() => onUpdateSettings({ textBlendMode: mode.id })}
                        className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'border-transparent text-black shadow-md'
                            : 'border-white/10 bg-white/5 text-white/70 hover:bg-white/10'
                        }`}
                        style={
                          isSelected
                            ? {
                                background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                              }
                            : {}
                        }
                      >
                        {mode.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Watermark Input */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">العلامة المائية / اسم القناة:</span>
                  <button
                    onClick={() => onUpdateSettings({ showWatermark: !settings.showWatermark })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      settings.showWatermark ? 'bg-cyan-400' : 'bg-white/20'
                    }`}
                    style={{ backgroundColor: settings.showWatermark ? activeColor : undefined }}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                        settings.showWatermark ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                      }`}
                    />
                  </button>
                </div>

                {settings.showWatermark && (
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="مثال: EGO_MUSIC7 أو @YourName"
                      value={settings.customWatermarkText}
                      onChange={(e) => onUpdateSettings({ customWatermarkText: e.target.value })}
                      className="w-full px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-sm font-bold text-white focus:outline-none focus:border-cyan-400 font-sans"
                    />
                    <div className="flex items-center gap-2 flex-wrap">
                      {['EGO_MUSIC7', 'RC_MUSIC', 'NEON_BEATS', '@CREATOR'].map((sug) => (
                        <button
                          key={sug}
                          onClick={() => onUpdateSettings({ customWatermarkText: sug })}
                          className="px-2.5 py-1 bg-white/5 hover:bg-white/10 rounded-lg text-[10px] font-mono text-white/70 cursor-pointer"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Song Title & Artist Toggles */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <span className="text-xs font-bold text-white block">عناصر النص داخل الشاشة:</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onUpdateSettings({ showTrackTitle: !settings.showTrackTitle })}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      settings.showTrackTitle
                        ? 'border-transparent bg-white/20 text-white shadow-sm'
                        : 'border-white/10 bg-white/5 text-white/50'
                    }`}
                  >
                    {settings.showTrackTitle ? 'اسم الأغنية: ظاهر' : 'اسم الأغنية: مخفي'}
                  </button>

                  <button
                    onClick={() => onUpdateSettings({ showTrackArtist: !settings.showTrackArtist })}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      settings.showTrackArtist
                        ? 'border-transparent bg-white/20 text-white shadow-sm'
                        : 'border-white/10 bg-white/5 text-white/50'
                    }`}
                  >
                    {settings.showTrackArtist ? 'اسم الفنان: ظاهر' : 'اسم الفنان: مخفي'}
                  </button>
                </div>
              </div>

              {/* Text Glow & Position */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-semibold text-white/80">موضع ظهور النص:</span>
                  <div className="flex gap-1.5">
                    {(['top', 'center', 'bottom'] as const).map((pos) => {
                      const isSelected = settings.textPosition === pos;
                      const labels = { top: 'أعلى', center: 'وسط', bottom: 'أسفل' };
                      return (
                        <button
                          key={pos}
                          onClick={() => onUpdateSettings({ textPosition: pos })}
                          className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                            isSelected ? 'bg-cyan-400 text-black' : 'bg-white/10 text-white/60'
                          }`}
                          style={
                            isSelected
                              ? {
                                  backgroundColor: activeColor,
                                  color: '#000',
                                }
                              : {}
                          }
                        >
                          {labels[pos]}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-white/5">
                  <span className="text-xs font-semibold text-white/80">توهج نيون للنص:</span>
                  <button
                    onClick={() => onUpdateSettings({ textGlow: !settings.textGlow })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      settings.textGlow ? 'bg-cyan-400' : 'bg-white/20'
                    }`}
                    style={{ backgroundColor: settings.textGlow ? activeColor : undefined }}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                        settings.textGlow ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB: SHAPES & STYLES & WAVE BLEND */}
          {activeTab === 'shapes' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Waves className="w-4 h-4" style={{ color: activeColor }} />
                  اختر نمط طيف الموجات الصوتي الرئيسي (10 أنماط)
                </h3>
                <p className="text-xs text-white/50">
                  جميع التصاميم متوافقة مع إطارات Avee ومزودة بفيزياء الترددات الحية
                </p>
              </div>

              {/* WAVE BLEND MODE SELECTOR (وضع مزج الموجات الصوتية) */}
              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-2">
                <label className="text-xs font-bold text-white/80 block">
                  وضع المزج اللوني للموجات الصوتية (Wave Blend Mode):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {BLEND_MODE_OPTIONS.map((mode) => {
                    const isSelected = settings.waveBlendMode === mode.id;
                    return (
                      <button
                        key={mode.id}
                        onClick={() => onUpdateSettings({ waveBlendMode: mode.id })}
                        className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'border-transparent text-black shadow-md'
                            : 'border-white/10 bg-white/5 text-white/70 hover:bg-white/10'
                        }`}
                        style={
                          isSelected
                            ? {
                                background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                              }
                            : {}
                        }
                        title={mode.desc}
                      >
                        {mode.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {stylesList.map((st) => {
                  const isSelected = settings.style === st.id;
                  return (
                    <button
                      key={st.id}
                      onClick={() => onUpdateSettings({ style: st.id })}
                      className={`p-3.5 rounded-2xl border text-right transition-all flex items-start gap-3 cursor-pointer ${
                        isSelected
                          ? 'border-transparent shadow-lg shadow-cyan-500/10'
                          : 'border-white/10 bg-[#151926] hover:bg-[#151926]/80'
                      }`}
                      style={
                        isSelected
                          ? {
                              backgroundColor: `${activeColor}15`,
                              borderColor: activeColor,
                            }
                          : {}
                      }
                    >
                      <div
                        className="p-2 rounded-xl mt-0.5 shrink-0"
                        style={{
                          backgroundColor: isSelected ? activeColor : 'rgba(255,255,255,0.06)',
                          color: isSelected ? '#000' : 'rgba(255,255,255,0.8)',
                        }}
                      >
                        {st.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span
                            className="font-bold text-sm block truncate"
                            style={{ color: isSelected ? activeColor : '#FFF' }}
                          >
                            {st.label}
                          </span>
                          {isSelected && <Check className="w-4 h-4 shrink-0" style={{ color: activeColor }} />}
                        </div>
                        <p className="text-[11px] text-white/40 mt-1 line-clamp-2 leading-relaxed">
                          {st.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB: GEOMETRY */}
          {activeTab === 'geometry' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Maximize2 className="w-4 h-4" style={{ color: activeColor }} />
                  الأبعاد والهندسة والتناظر
                </h3>
              </div>

              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">عدد أعمدة الطيف (Bar Count)</span>
                    <span className="font-mono text-white/90">{settings.barCount} عمود</span>
                  </div>
                  <input
                    type="range"
                    min="16"
                    max="128"
                    step="8"
                    value={settings.barCount}
                    onChange={(e) => onUpdateSettings({ barCount: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">عرض العمود (Bar Width)</span>
                    <span className="font-mono text-white/90">{settings.barWidth} px</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="12"
                    step="1"
                    value={settings.barWidth}
                    onChange={(e) => onUpdateSettings({ barWidth: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">المسافة بين الأعمدة (Spacing)</span>
                    <span className="font-mono text-white/90">{settings.barSpacing} px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    step="1"
                    value={settings.barSpacing}
                    onChange={(e) => onUpdateSettings({ barSpacing: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">انحناء الحواف (Corner Radius)</span>
                    <span className="font-mono text-white/90">{settings.roundness} px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="12"
                    step="1"
                    value={settings.roundness}
                    onChange={(e) => onUpdateSettings({ roundness: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">سعة وارتفاع الموجة (Wave Amplitude)</span>
                    <span className="font-mono text-white/90">{settings.waveAmplitude.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.4"
                    max="2.5"
                    step="0.1"
                    value={settings.waveAmplitude}
                    onChange={(e) => onUpdateSettings({ waveAmplitude: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB: AUDIO & RESPONSIVENESS */}
          {activeTab === 'audio' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4" style={{ color: activeColor }} />
                  التفاعل الصوتي ومضخم الترددات (Bass / Treble EQ)
                </h3>
              </div>

              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">حساسية الالتقاط (Sensitivity)</span>
                    <span className="font-mono text-white/90">{settings.sensitivity.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.4"
                    max="2.5"
                    step="0.1"
                    value={settings.sensitivity}
                    onChange={(e) => onUpdateSettings({ sensitivity: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">مضخم الباس (Bass Boost)</span>
                    <span className="font-mono text-white/90">{settings.bassBoost.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.5"
                    step="0.1"
                    value={settings.bassBoost}
                    onChange={(e) => onUpdateSettings({ bassBoost: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">نعومة الحركة (FFT Smoothing)</span>
                    <span className="font-mono text-white/90">{settings.smoothing.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.2"
                    max="0.95"
                    step="0.05"
                    value={settings.smoothing}
                    onChange={(e) => onUpdateSettings({ smoothing: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB: LIGHTING & PARTICLES */}
          {activeTab === 'lighting' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4" style={{ color: activeColor }} />
                  الإضاءة، النيون، والبوكيه المتطاير
                </h3>
              </div>

              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">كثافة توهج النيون (Glow Intensity)</span>
                    <span className="font-mono text-white/90">{settings.glowIntensity.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="2.5"
                    step="0.1"
                    value={settings.glowIntensity}
                    onChange={(e) => onUpdateSettings({ glowIntensity: Number(e.target.value) })}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    style={{ accentColor: activeColor }}
                  />
                </div>

                {/* Particle Mode Selection */}
                <div className="space-y-2 pt-2 border-t border-white/5">
                  <label className="text-xs font-bold text-white/80 block">
                    تأثير الجسيمات المتطايرة في الهواء:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { id: 'sparks', label: 'شرارات نيونية' },
                      { id: 'bokeh_dots', label: 'دوائر بوكيه ضوئية' },
                      { id: 'dust', label: 'غبار كوني ناعم' },
                      { id: 'none', label: 'إيقاف الجسيمات' },
                    ].map((p) => {
                      const isSelected = settings.particleMode === p.id;
                      return (
                        <button
                          key={p.id}
                          onClick={() => onUpdateSettings({ particleMode: p.id as ParticleMode })}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'border-transparent text-black shadow-md'
                              : 'border-white/10 bg-white/5 text-white/70'
                          }`}
                          style={
                            isSelected
                              ? {
                                  background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
                                }
                              : {}
                          }
                        >
                          {p.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: COLORS */}
          {activeTab === 'colors' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <PaletteIcon className="w-4 h-4" style={{ color: activeColor }} />
                  أنماط الألوان والتخصيص الفردي
                </h3>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {COLOR_PALETTES.map((pal) => {
                  const isSelected = settings.colorMode === 'palette' && currentPalette.id === pal.id;
                  return (
                    <button
                      key={pal.id}
                      onClick={() => {
                        onSelectPalette(pal);
                        onUpdateSettings({ colorMode: 'palette' });
                      }}
                      className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'border-transparent shadow-lg'
                          : 'border-white/10 bg-[#151926] hover:bg-[#151926]/80'
                      }`}
                      style={
                        isSelected
                          ? {
                              backgroundColor: `${pal.colorOne}18`,
                              borderColor: pal.colorOne,
                            }
                          : {}
                      }
                    >
                      <div>
                        <span className="text-xs font-bold text-white block">{pal.name}</span>
                        <div className="flex gap-1.5 mt-2">
                          <span
                            className="w-3.5 h-3.5 rounded-full"
                            style={{ backgroundColor: pal.colorOne }}
                          />
                          <span
                            className="w-3.5 h-3.5 rounded-full"
                            style={{ backgroundColor: pal.colorTwo }}
                          />
                        </div>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-white" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB: PLAYBACK & SPEED */}
          {activeTab === 'playback' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Gauge className="w-4 h-4" style={{ color: activeColor }} />
                  سرعة التشغيل والتلاشي الصوتي
                </h3>
              </div>

              <div className="bg-[#151926] p-4 rounded-2xl border border-white/5 space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-white/70">سرعة تشغيل الصوت (Speed)</span>
                    <span className="font-mono text-white/90">{settings.playbackRate}x</span>
                  </div>
                  <div className="flex gap-2">
                    {[0.75, 1.0, 1.25, 1.5].map((rate) => (
                      <button
                        key={rate}
                        onClick={() => onUpdateSettings({ playbackRate: rate })}
                        className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          settings.playbackRate === rate
                            ? 'bg-cyan-400 text-black'
                            : 'bg-white/10 text-white/70'
                        }`}
                        style={
                          settings.playbackRate === rate
                            ? { backgroundColor: activeColor, color: '#000' }
                            : {}
                        }
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                  <span className="text-xs font-semibold text-white/80">
                    التلاشي التدريجي بين المقاطع (Crossfade)
                  </span>
                  <button
                    onClick={() => onUpdateSettings({ fadeEnabled: !settings.fadeEnabled })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      settings.fadeEnabled ? 'bg-cyan-400' : 'bg-white/20'
                    }`}
                    style={{ backgroundColor: settings.fadeEnabled ? activeColor : undefined }}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-black transition-transform ${
                        settings.fadeEnabled ? 'translate-x-[-22px]' : 'translate-x-[-3px]'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#151926] flex items-center justify-between">
          <button
            onClick={handleResetToDefault}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white/50 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>استعادة الإعدادات الافتراضية</span>
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-xl text-xs font-bold text-black shadow-lg cursor-pointer transition-all hover:scale-[1.02]"
            style={{
              background: `linear-gradient(135deg, ${activeColor}, ${secondaryColor})`,
            }}
          >
            حفظ وتطبيق
          </button>
        </div>
      </div>
    </div>
  );
};
