import React, { useEffect, useRef } from 'react';
import { VisualizerSettings, VisualizerLayer, CanvasBlendMode } from '../types';
import { audioEngine } from '../utils/audioEngine';

interface VisualizerCanvasProps {
  isPlaying: boolean;
  colorOne: string;
  colorTwo: string;
  settings: VisualizerSettings;
  trackTitle?: string;
  trackArtist?: string;
  isControlsVisible?: boolean;
  canvasRefCallback?: (canvas: HTMLCanvasElement | null) => void;
}

function lerpColor(a: string, b: string, amount: number): string {
  const cleanA = a.replace('#', '');
  const cleanB = b.replace('#', '');
  const ah = parseInt(cleanA.length === 3 ? cleanA.split('').map((c) => c + c).join('') : cleanA, 16);
  const ar = (ah >> 16) & 0xff;
  const ag = (ah >> 8) & 0xff;
  const ab = ah & 0xff;

  const bh = parseInt(cleanB.length === 3 ? cleanB.split('').map((c) => c + c).join('') : cleanB, 16);
  const br = (bh >> 16) & 0xff;
  const bg = (bh >> 8) & 0xff;
  const bb = bh & 0xff;

  const rr = Math.round(ar + amount * (br - ar));
  const rg = Math.round(ag + amount * (bg - ag));
  const rb = Math.round(ab + amount * (bb - ab));

  return `rgb(${rr}, ${rg}, ${rb})`;
}

function hexToRgba(hex: string, alpha: number): string {
  const cleanHex = hex.replace('#', '');
  const fullHex = cleanHex.length === 3 ? cleanHex.split('').map((c) => c + c).join('') : cleanHex;
  const h = parseInt(fullHex, 16);
  const r = (h >> 16) & 0xff;
  const g = (h >> 8) & 0xff;
  const b = h & 0xff;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

export const VisualizerCanvas: React.FC<VisualizerCanvasProps> = ({
  isPlaying,
  colorOne,
  colorTwo,
  settings,
  trackTitle = '',
  trackArtist = '',
  isControlsVisible = true,
  canvasRefCallback,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const smoothedLevelsRef = useRef<number[]>([]);
  const peakLevelsRef = useRef<number[]>([]);
  const animTimeRef = useRef<number>(0);
  const particlesRef = useRef<Particle[]>([]);
  const beatPulseRef = useRef<number>(0);

  const bgImageElementRef = useRef<HTMLImageElement | null>(null);
  const centerImageElementRef = useRef<HTMLImageElement | null>(null);
  const layerImagesCacheRef = useRef<Map<string, HTMLImageElement>>(new Map());

  const {
    style,
    barCount,
    barWidth,
    barSpacing,
    roundness,
    waveAmplitude,
    glowIntensity,
    sensitivity,
    smoothing,
    speed,
    bassBoost,
    trebleBoost,
    showPeakCaps,
    beatPulse,
    fillOpacity,
    backgroundTheme,
    showGrid,
    gridSpacing,
    showCenterGlow,
    backgroundImageUrl,
    backgroundBlur,
    backgroundOpacity,
    bgScale,
    bgOffsetX,
    bgOffsetY,
    bgAudioMotion,
    bgMotionIntensity,
    bgBlendMode,
    waveCenterImageUrl,
    waveCenterImageSpin,
    waveCenterImageSize,
    waveCenterImageBorder,
    centerAvatarBlendMode,
    waveBlendMode,
    textBlendMode,
    layers,
    enableSecondaryWave,
    secondaryWaveStyle,
    secondaryWaveHeight,
    showAngelWings,
    wingsSpread,
    showRoyalCrown,
    crownScale,
    centerFrameShape,
    showInnerEqualizer,
    particleMode,
    particleSpeed,
    particleCount,
    titleHideMode,
  } = settings;

  // Preload background image
  useEffect(() => {
    if (backgroundImageUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = backgroundImageUrl;
      img.onload = () => {
        bgImageElementRef.current = img;
      };
    } else {
      bgImageElementRef.current = null;
    }
  }, [backgroundImageUrl]);

  // Preload center wave image
  useEffect(() => {
    if (waveCenterImageUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = waveCenterImageUrl;
      img.onload = () => {
        centerImageElementRef.current = img;
      };
    } else {
      centerImageElementRef.current = null;
    }
  }, [waveCenterImageUrl]);

  // Preload custom layers images
  useEffect(() => {
    const cache = layerImagesCacheRef.current;
    layers.forEach((layer) => {
      const url = layer.imageUrl;
      if (url && !cache.has(url)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = url;
        img.onload = () => {
          cache.set(url, img);
        };
      }
    });
  }, [layers]);

  useEffect(() => {
    if (canvasRefCallback && canvasRef.current) {
      canvasRefCallback(canvasRef.current);
    }
  }, [canvasRefCallback]);

  useEffect(() => {
    audioEngine.setSmoothing(smoothing);
  }, [smoothing]);

  useEffect(() => {
    smoothedLevelsRef.current = new Array(barCount).fill(0.08);
    peakLevelsRef.current = new Array(barCount).fill(0.08);
  }, [barCount]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;

    const render = (timestamp: number) => {
      if (!isRunning) return;

      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();

      const targetWidth = Math.floor(rect.width * dpr);
      const targetHeight = Math.floor(rect.height * dpr);

      if (canvas.width !== targetWidth || canvas.height !== targetHeight) {
        canvas.width = targetWidth;
        canvas.height = targetHeight;
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      const width = rect.width;
      const height = rect.height;

      animTimeRef.current = timestamp * 0.0025 * speed;
      const time = animTimeRef.current;
      const rawFreqData = audioEngine.getFrequencyData();

      const levels = smoothedLevelsRef.current;
      const peaks = peakLevelsRef.current;
      if (levels.length !== barCount) {
        smoothedLevelsRef.current = new Array(barCount).fill(0.08);
      }
      if (peaks.length !== barCount) {
        peakLevelsRef.current = new Array(barCount).fill(0.08);
      }

      let hasRealAudio = false;
      let totalBassEnergy = 0;

      if (rawFreqData && isPlaying) {
        for (let j = 0; j < Math.min(64, rawFreqData.length); j++) {
          if (rawFreqData[j] > 10) {
            hasRealAudio = true;
          }
          if (j < 12) {
            totalBassEnergy += rawFreqData[j];
          }
        }
      }

      const avgBass = totalBassEnergy / 12;
      const currentBeatTarget = avgBass > 140 ? (avgBass - 140) / 115 : 0;
      beatPulseRef.current += (currentBeatTarget - beatPulseRef.current) * 0.35;
      const activePulse = beatPulse ? beatPulseRef.current : 0;

      for (let i = 0; i < barCount; i++) {
        let targetLevel = 0.05;
        const fraction = i / (barCount - 1 || 1);

        if (hasRealAudio && rawFreqData) {
          const binCount = rawFreqData.length;
          // Precision logarithmic frequency distribution (sub-bass to treble)
          const f0 = Math.pow(fraction, 1.6);
          const f1 = Math.pow((i + 1) / (barCount || 1), 1.6);
          const binStart = Math.min(binCount - 1, Math.floor(f0 * (binCount * 0.88)));
          const binEnd = Math.min(binCount - 1, Math.max(binStart + 1, Math.floor(f1 * (binCount * 0.88))));

          let sum = 0;
          for (let b = binStart; b <= binEnd; b++) {
            sum += rawFreqData[b];
          }
          const sample = sum / (binEnd - binStart + 1);

          let weight = 1.0;
          if (fraction < 0.28) {
            weight *= bassBoost;
          } else if (fraction > 0.65) {
            weight *= trebleBoost;
          }

          const normalized = (sample / 255.0) * sensitivity * weight;
          targetLevel = Math.max(0.03, Math.min(1.0, normalized));
        } else if (isPlaying) {
          const wave1 = Math.sin(time * 2.5 + i * 0.32);
          const wave2 = Math.cos(time * 1.8 - i * 0.22);
          const wave3 = Math.sin(time * 3.4 + i * 0.15);
          const sim = 0.18 + (Math.abs(wave1) * 0.4 + Math.abs(wave2) * 0.25 + Math.abs(wave3) * 0.18);
          targetLevel = Math.max(0.04, Math.min(1.0, sim * sensitivity));
        } else {
          const idleWave = Math.sin(time * 1.2 + i * 0.2);
          targetLevel = 0.04 + Math.abs(idleWave) * 0.07;
        }

        targetLevel = Math.max(0.02, Math.min(1.0, targetLevel * waveAmplitude));

        const prev = levels[i] || 0.05;
        if (targetLevel > prev) {
          levels[i] = prev + (targetLevel - prev) * 0.52;
        } else {
          levels[i] = prev - (prev - targetLevel) * 0.16;
        }

        if (levels[i] >= (peaks[i] || 0)) {
          peaks[i] = levels[i];
        } else {
          peaks[i] = Math.max(0.02, (peaks[i] || 0) - 0.012);
        }
      }

      // 1. Draw Background with Scale, Pan, and Audio Motion
      drawBackground(
        ctx,
        width,
        height,
        colorOne,
        colorTwo,
        backgroundTheme,
        showGrid,
        gridSpacing,
        showCenterGlow,
        glowIntensity,
        activePulse,
        bgImageElementRef.current,
        backgroundBlur,
        backgroundOpacity,
        bgScale,
        bgOffsetX,
        bgOffsetY,
        bgAudioMotion,
        bgMotionIntensity,
        bgBlendMode
      );

      // 2. Draw Custom Dynamic Layers (Under Waves)
      drawCustomLayers(
        ctx,
        width,
        height,
        layers,
        layerImagesCacheRef.current,
        activePulse,
        time
      );

      // 3. Draw Floating Bokeh or Sparks or Dust Particles
      if (particleMode !== 'none') {
        drawParticlesFX(
          ctx,
          width,
          height,
          levels,
          colorOne,
          colorTwo,
          glowIntensity,
          activePulse,
          particleMode,
          particleSpeed,
          particleCount,
          particlesRef
        );
      }

      // 4. Draw Secondary Stacked Wave (موجات فوق بعض)
      if (enableSecondaryWave && secondaryWaveStyle !== 'none') {
        drawSecondaryWave(
          ctx,
          width,
          height,
          levels,
          peaks,
          colorOne,
          colorTwo,
          secondaryWaveStyle,
          secondaryWaveHeight,
          glowIntensity,
          showPeakCaps,
          waveBlendMode
        );
      }

      // 5. Draw Center Emblems: Angel Wings & Royal Crown
      const cx = width / 2;
      const cy = height / 2;
      const baseRadius = Math.max(35, Math.min(width, height) * 0.22);
      const pulseRadius = baseRadius * (1 + activePulse * 0.1);

      if (showAngelWings) {
        drawAngelWings(ctx, cx, cy, pulseRadius, wingsSpread, activePulse, colorOne, glowIntensity);
      }

      if (showRoyalCrown) {
        drawRoyalCrown(ctx, cx, cy, pulseRadius, crownScale, activePulse, colorOne, glowIntensity);
      }

      // 6. Render Primary Selected Visualizer Mode with Wave Blend Mode
      ctx.save();
      ctx.globalCompositeOperation = waveBlendMode || 'source-over';
      switch (style) {
        case 'mirror':
          renderMirrorVisualizer(
            ctx,
            width,
            height,
            levels,
            peaks,
            colorOne,
            colorTwo,
            barWidth,
            barSpacing,
            roundness,
            glowIntensity,
            showPeakCaps,
            fillOpacity
          );
          break;

        case 'bars':
          renderClassicBarsVisualizer(
            ctx,
            width,
            height,
            levels,
            peaks,
            colorOne,
            colorTwo,
            barWidth,
            barSpacing,
            roundness,
            glowIntensity,
            showPeakCaps,
            fillOpacity
          );
          break;

        case 'wave':
          renderSmoothWaveVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            fillOpacity,
            time
          );
          break;

        case 'radial':
          renderRadialVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            activePulse,
            time,
            centerFrameShape
          );
          break;

        case 'spiral':
          renderSpiralVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            time
          );
          break;

        case 'oscilloscope':
          renderOscilloscopeVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            time
          );
          break;

        case 'particles':
          break;

        case 'cyber_grid':
          renderCyber3DGridVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            fillOpacity,
            time
          );
          break;

        case 'starburst':
          renderStarburstVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            activePulse,
            time
          );
          break;

        case 'capsules':
          renderCapsulesVisualizer(
            ctx,
            width,
            height,
            levels,
            peaks,
            colorOne,
            colorTwo,
            barWidth,
            barSpacing,
            roundness,
            glowIntensity,
            fillOpacity
          );
          break;

        default:
          renderRadialVisualizer(
            ctx,
            width,
            height,
            levels,
            colorOne,
            colorTwo,
            barWidth,
            glowIntensity,
            activePulse,
            time,
            centerFrameShape
          );
      }
      ctx.restore();

      // 7. Center Frame Decoration & Inner Equalizer
      drawCenterFrameAndInnerEqualizer(
        ctx,
        cx,
        cy,
        pulseRadius,
        centerFrameShape,
        showInnerEqualizer,
        levels,
        colorOne,
        colorTwo,
        glowIntensity,
        activePulse
      );

      // 8. Center Avatar / Logo Image on Waves with Blend Mode
      drawCenterImageOnWaves(
        ctx,
        width,
        height,
        centerImageElementRef.current,
        waveCenterImageSize,
        waveCenterImageSpin,
        waveCenterImageBorder,
        centerAvatarBlendMode,
        time,
        activePulse,
        colorOne,
        glowIntensity
      );

      // 9. In-Canvas Text & Watermark (Synchronized Auto-Hide with Controls)
      const shouldDrawTitle =
        titleHideMode === 'always_visible'
          ? true
          : titleHideMode === 'hidden'
          ? false
          : isControlsVisible; // 'sync_with_bar'

      drawTextOverlays(
        ctx,
        width,
        height,
        trackTitle,
        trackArtist,
        settings,
        colorOne,
        colorTwo,
        shouldDrawTitle,
        textBlendMode
      );

      ctx.restore();
      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      isRunning = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [
    isPlaying,
    colorOne,
    colorTwo,
    style,
    barCount,
    barWidth,
    barSpacing,
    roundness,
    waveAmplitude,
    glowIntensity,
    sensitivity,
    smoothing,
    speed,
    bassBoost,
    trebleBoost,
    showPeakCaps,
    beatPulse,
    fillOpacity,
    backgroundTheme,
    showGrid,
    gridSpacing,
    showCenterGlow,
    backgroundImageUrl,
    backgroundBlur,
    backgroundOpacity,
    bgScale,
    bgOffsetX,
    bgOffsetY,
    bgAudioMotion,
    bgMotionIntensity,
    bgBlendMode,
    waveCenterImageUrl,
    waveCenterImageSpin,
    waveCenterImageSize,
    waveCenterImageBorder,
    centerAvatarBlendMode,
    waveBlendMode,
    textBlendMode,
    layers,
    enableSecondaryWave,
    secondaryWaveStyle,
    secondaryWaveHeight,
    showAngelWings,
    wingsSpread,
    showRoyalCrown,
    crownScale,
    centerFrameShape,
    showInnerEqualizer,
    particleMode,
    particleSpeed,
    particleCount,
    trackTitle,
    trackArtist,
    isControlsVisible,
    titleHideMode,
  ]);

  return <canvas ref={canvasRef} className="w-full h-full block" />;
};

/* =========================================================================
 * Background Rendering with Pan, Zoom, Audio-Motion, and Blend Modes
 * ========================================================================= */
function drawBackground(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  colorOne: string,
  colorTwo: string,
  theme: string,
  showGrid: boolean,
  gridSpacing: number,
  showCenterGlow: boolean,
  glowIntensity: number,
  activePulse: number,
  bgImg: HTMLImageElement | null,
  backgroundBlur: number,
  backgroundOpacity: number,
  bgScale: number = 1.0,
  bgOffsetX: number = 0,
  bgOffsetY: number = 0,
  bgAudioMotion: boolean = true,
  bgMotionIntensity: number = 1.0,
  bgBlendMode: CanvasBlendMode = 'source-over'
) {
  ctx.clearRect(0, 0, width, height);

  if (bgImg && bgImg.complete && bgImg.naturalWidth > 0) {
    ctx.save();
    ctx.fillStyle = '#050608';
    ctx.fillRect(0, 0, width, height);

    ctx.globalAlpha = Math.max(0.05, Math.min(1.0, backgroundOpacity));
    ctx.globalCompositeOperation = bgBlendMode || 'source-over';

    if (backgroundBlur > 0) {
      ctx.filter = `blur(${backgroundBlur}px)`;
    }

    const imgRatio = bgImg.naturalWidth / bgImg.naturalHeight;
    const canvasRatio = width / height;

    // Apply Zoom & Audio-reactive bass pulse
    const motionPulse = bgAudioMotion ? 1 + activePulse * 0.1 * bgMotionIntensity : 1.0;
    const effectiveScale = (bgScale || 1.0) * motionPulse;

    let baseW = width;
    let baseH = height;
    if (imgRatio > canvasRatio) {
      baseW = height * imgRatio;
    } else {
      baseH = width / imgRatio;
    }

    const dw = baseW * effectiveScale;
    const dh = baseH * effectiveScale;

    // Center plus Pan offsets (percentage to px)
    const panPixelX = (bgOffsetX / 100) * (width * 0.6);
    const panPixelY = (bgOffsetY / 100) * (height * 0.6);
    const dx = (width - dw) / 2 + panPixelX;
    const dy = (height - dh) / 2 + panPixelY;

    ctx.drawImage(bgImg, dx, dy, dw, dh);
    ctx.restore();

    // Dark vignette for contrast
    const vigGrad = ctx.createRadialGradient(
      width / 2,
      height / 2,
      Math.min(width, height) * 0.28,
      width / 2,
      height / 2,
      Math.max(width, height) * 0.75
    );
    vigGrad.addColorStop(0, 'rgba(0,0,0,0.2)');
    vigGrad.addColorStop(1, 'rgba(0,0,0,0.85)');
    ctx.fillStyle = vigGrad;
    ctx.fillRect(0, 0, width, height);
  } else {
    let baseColor = '#10131D';
    if (theme === 'pure_black') baseColor = '#050608';
    if (theme === 'deep_space') baseColor = '#070914';
    if (theme === 'vibrant_glow') baseColor = '#0C0F1A';
    if (theme === 'matrix') baseColor = '#060E0A';

    const bgGrad = ctx.createLinearGradient(0, 0, width, height);
    const pulseFactor = 1 + activePulse * 0.4;

    if (theme === 'vibrant_glow') {
      bgGrad.addColorStop(0, hexToRgba(colorOne, 0.18 * pulseFactor));
      bgGrad.addColorStop(0.5, baseColor);
      bgGrad.addColorStop(1, hexToRgba(colorTwo, 0.22 * pulseFactor));
    } else if (theme === 'matrix') {
      bgGrad.addColorStop(0, 'rgba(0, 255, 120, 0.08)');
      bgGrad.addColorStop(0.5, baseColor);
      bgGrad.addColorStop(1, hexToRgba(colorOne, 0.1));
    } else {
      bgGrad.addColorStop(0, hexToRgba(colorOne, 0.08 * pulseFactor));
      bgGrad.addColorStop(0.5, baseColor);
      bgGrad.addColorStop(1, hexToRgba(colorTwo, 0.11 * pulseFactor));
    }

    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);
  }

  if (showGrid) {
    const spacing = Math.max(12, gridSpacing);
    ctx.strokeStyle =
      theme === 'matrix' ? 'rgba(0, 255, 120, 0.05)' : 'rgba(255, 255, 255, 0.032)';
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    for (let x = 0; x < width; x += spacing) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
    }
    for (let y = 0; y < height; y += spacing) {
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
    }
    ctx.stroke();
  }

  if (showCenterGlow) {
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.min(width, height) * (0.65 + activePulse * 0.25);
    const radialGlow = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(10, radius));
    radialGlow.addColorStop(0, hexToRgba(colorOne, (0.16 + activePulse * 0.15) * glowIntensity));
    radialGlow.addColorStop(0.65, hexToRgba(colorTwo, 0.06 * glowIntensity));
    radialGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = radialGlow;
    ctx.fillRect(0, 0, width, height);
  }
}

/* =========================================================================
 * Draw Unlimited Custom Layers with Blend Modes
 * ========================================================================= */
function drawCustomLayers(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  layers: VisualizerLayer[],
  cache: Map<string, HTMLImageElement>,
  activePulse: number,
  time: number
) {
  if (!layers || layers.length === 0) return;

  layers.forEach((layer) => {
    if (!layer.visible) return;

    // 1. Text Layer
    if (layer.type === 'text' || (!layer.imageUrl && layer.text)) {
      ctx.save();
      ctx.globalCompositeOperation = layer.blendMode || 'source-over';
      ctx.globalAlpha = Math.max(0, Math.min(1.0, layer.opacity ?? 1.0));

      const targetX = width / 2 + (layer.x / 100) * (width * 0.5);
      const targetY = height / 2 + (layer.y / 100) * (height * 0.5);

      ctx.translate(targetX, targetY);

      if (layer.rotation) {
        ctx.rotate((layer.rotation * Math.PI) / 180);
      }

      const reactiveScale = layer.audioReactive ? 1 + activePulse * 0.2 : 1.0;
      const fontSize = Math.max(10, Math.floor(22 * (layer.scale || 1.0) * reactiveScale));

      ctx.font = `900 ${fontSize}px 'Cairo', sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = layer.textColor || '#FFFFFF';
      ctx.shadowColor = layer.textColor || '#00E5FF';
      ctx.shadowBlur = 18;
      ctx.fillText(layer.text || '', 0, 0);
      ctx.restore();
      return;
    }

    // 2. Image Layer
    if (!layer.imageUrl) return;
    const img = cache.get(layer.imageUrl);
    if (!img || !img.complete || img.naturalWidth <= 0) return;

    ctx.save();
    ctx.globalCompositeOperation = layer.blendMode || 'source-over';
    ctx.globalAlpha = Math.max(0, Math.min(1.0, layer.opacity ?? 1.0));

    // Center is (width/2, height/2), apply offset percentage
    const targetX = width / 2 + (layer.x / 100) * (width * 0.5);
    const targetY = height / 2 + (layer.y / 100) * (height * 0.5);

    ctx.translate(targetX, targetY);

    if (layer.rotation) {
      ctx.rotate((layer.rotation * Math.PI) / 180);
    }

    const reactiveScale = layer.audioReactive ? 1 + activePulse * 0.18 : 1.0;
    const scale = (layer.scale || 1.0) * reactiveScale;

    // Normalizing dimension relative to canvas size
    const baseDim = Math.min(width, height) * 0.38;
    const imgAspect = img.naturalWidth / img.naturalHeight;
    let w = baseDim * scale;
    let h = baseDim * scale;
    if (imgAspect >= 1) {
      h = w / imgAspect;
    } else {
      w = h * imgAspect;
    }

    ctx.drawImage(img, -w / 2, -h / 2, w, h);
    ctx.restore();
  });
}

/* =========================================================================
 * Particles & Bokeh
 * ========================================================================= */
function drawParticlesFX(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  glowIntensity: number,
  activePulse: number,
  mode: string,
  speed: number,
  countMax: number,
  particlesRef: React.MutableRefObject<Particle[]>
) {
  const particles = particlesRef.current;
  const avgLevel = levels.reduce((acc, v) => acc + v, 0) / (levels.length || 1);

  const spawnRate = mode === 'bokeh_dots' ? 2 : Math.floor(avgLevel * 8 + activePulse * 10);
  for (let s = 0; s < spawnRate; s++) {
    if (particles.length < countMax) {
      if (mode === 'bokeh_dots') {
        const BOKEH_COLORS = [colorOne, colorTwo, '#00FF66', '#FF3366', '#FFCC00', '#00E5FF'];
        const chosenColor = BOKEH_COLORS[Math.floor(Math.random() * BOKEH_COLORS.length)];
        const fromTop = Math.random() > 0.5;

        particles.push({
          x: Math.random() * width,
          y: fromTop ? -10 : height + 10,
          vx: (Math.random() - 0.5) * 0.8 * speed,
          vy: (fromTop ? 1 : -1) * (Math.random() * 1.5 + 0.8) * speed,
          size: Math.random() * 5 + 3,
          color: chosenColor,
          alpha: 0.9,
          life: 0,
          maxLife: Math.random() * 120 + 80,
        });
      } else {
        const angle = Math.random() * Math.PI * 2;
        const sparkSpeed = (Math.random() * 4 + avgLevel * 5) * speed;
        particles.push({
          x: width / 2 + (Math.random() - 0.5) * 40,
          y: height / 2 + (Math.random() - 0.5) * 40,
          vx: Math.cos(angle) * sparkSpeed,
          vy: Math.sin(angle) * sparkSpeed,
          size: Math.random() * 3 + 1.5,
          color: Math.random() > 0.5 ? colorOne : colorTwo,
          alpha: 1.0,
          life: 0,
          maxLife: Math.random() * 50 + 25,
        });
      }
    }
  }

  ctx.save();
  ctx.shadowBlur = 10 * glowIntensity;

  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life++;
    p.x += p.vx;
    p.y += p.vy;
    p.alpha = Math.max(0, 1 - p.life / p.maxLife);

    if (p.life >= p.maxLife || p.x < -30 || p.x > width + 30 || p.y < -30 || p.y > height + 30) {
      particles.splice(i, 1);
      continue;
    }

    ctx.fillStyle = hexToRgba(p.color, p.alpha);
    ctx.shadowColor = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size * (0.8 + activePulse * 0.4), 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/* =========================================================================
 * Secondary Stacked Wave
 * ========================================================================= */
function drawSecondaryWave(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  peaks: number[],
  colorOne: string,
  colorTwo: string,
  style: string,
  scalePref: number,
  glowIntensity: number,
  showPeaks: boolean,
  blendMode: CanvasBlendMode = 'source-over'
) {
  const count = Math.min(64, levels.length);
  const baseline = height - 24;
  const barW = Math.max(1.5, (width * 0.9) / count - 1.5);
  const startX = width * 0.05;

  ctx.save();
  ctx.globalCompositeOperation = blendMode || 'source-over';
  ctx.shadowBlur = 12 * glowIntensity;

  if (style === 'bottom_bars') {
    for (let i = 0; i < count; i++) {
      const x = startX + i * (barW + 1.5);
      const fraction = i / (count - 1 || 1);
      const barColor = lerpColor(colorOne, colorTwo, fraction);
      const barHeight = Math.max(3, levels[i] * (height * 0.16) * scalePref);

      ctx.fillStyle = hexToRgba(barColor, 0.85);
      ctx.shadowColor = barColor;
      ctx.fillRect(x, baseline - barHeight, barW, barHeight);

      if (showPeaks && peaks[i]) {
        const peakY = baseline - Math.max(4, peaks[i] * (height * 0.16) * scalePref) - 3;
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowColor = '#FFFFFF';
        ctx.fillRect(x, peakY, barW, 1.8);
      }
    }
  } else if (style === 'mirror_bars') {
    const centerY = height * 0.82;
    for (let i = 0; i < count; i++) {
      const x = startX + i * (barW + 1.5);
      const fraction = i / (count - 1 || 1);
      const barColor = lerpColor(colorOne, colorTwo, fraction);
      const h = Math.max(2, (levels[i] * (height * 0.12) * scalePref) / 2);

      ctx.fillStyle = hexToRgba(barColor, 0.8);
      ctx.shadowColor = barColor;
      ctx.fillRect(x, centerY - h, barW, h);
      ctx.fillRect(x, centerY, barW, h);
    }
  } else {
    ctx.beginPath();
    ctx.moveTo(0, height * 0.78);
    for (let i = 0; i < count; i++) {
      const x = (i / (count - 1)) * width;
      const y = height * 0.78 - levels[i] * 35 * scalePref;
      ctx.lineTo(x, y);
    }
    ctx.strokeStyle = colorOne;
    ctx.shadowColor = colorOne;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  ctx.restore();
}

/* =========================================================================
 * Neon Angel Wings
 * ========================================================================= */
function drawAngelWings(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  spread: number,
  activePulse: number,
  color: string,
  glowIntensity: number
) {
  ctx.save();
  ctx.shadowBlur = 18 * glowIntensity;
  ctx.shadowColor = color;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.lineCap = 'round';

  const flap = 1 + activePulse * 0.18;
  const wingWidth = radius * 1.5 * spread * flap;
  const wingHeight = radius * 1.1 * flap;

  drawSingleWing(ctx, cx - radius * 0.7, cy - radius * 0.1, -1, wingWidth, wingHeight);
  drawSingleWing(ctx, cx + radius * 0.7, cy - radius * 0.1, 1, wingWidth, wingHeight);

  ctx.restore();
}

function drawSingleWing(
  ctx: CanvasRenderingContext2D,
  startX: number,
  startY: number,
  dir: number,
  w: number,
  h: number
) {
  const feathers = 4;
  for (let f = 0; f < feathers; f++) {
    const fraction = f / (feathers - 1);
    const tipX = startX + dir * (w * (0.65 + fraction * 0.45));
    const tipY = startY - h * (0.75 - fraction * 0.65);
    const c1x = startX + dir * (w * 0.3);
    const c1y = startY - h * 0.6;
    const c2x = startX + dir * (w * 0.7);
    const c2y = tipY + 10;

    ctx.beginPath();
    ctx.moveTo(startX, startY + f * 4);
    ctx.bezierCurveTo(c1x, c1y, c2x, c2y, tipX, tipY);
    ctx.bezierCurveTo(c2x - dir * 10, c2y + 12, startX + dir * 15, startY + 15, startX, startY + (f + 1) * 8);
    ctx.stroke();

    ctx.fillStyle = hexToRgba(ctx.strokeStyle as string || '#FFF', 0.08);
    ctx.fill();
  }
}

/* =========================================================================
 * Royal Glowing Crown
 * ========================================================================= */
function drawRoyalCrown(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  crownScale: number,
  activePulse: number,
  color: string,
  glowIntensity: number
) {
  ctx.save();
  ctx.shadowBlur = 18 * glowIntensity;
  ctx.shadowColor = color;
  ctx.strokeStyle = color;
  ctx.fillStyle = hexToRgba(color, 0.15);
  ctx.lineWidth = 2.2;
  ctx.lineJoin = 'round';

  const pulse = 1 + activePulse * 0.15;
  const crownW = radius * 0.9 * crownScale * pulse;
  const crownH = radius * 0.55 * crownScale * pulse;
  const baseY = cy - radius - 8;

  ctx.beginPath();
  ctx.moveTo(cx - crownW / 2, baseY);
  ctx.quadraticCurveTo(cx, baseY - 5, cx + crownW / 2, baseY);

  const p1x = cx + crownW / 2;
  const p1y = baseY - crownH * 0.65;
  const v1x = cx + crownW * 0.28;
  const v1y = baseY - crownH * 0.35;

  const p2x = cx + crownW * 0.2;
  const p2y = baseY - crownH * 0.85;
  const v2x = cx + crownW * 0.08;
  const v2y = baseY - crownH * 0.45;

  const pCenter = cx;
  const pCenterY = baseY - crownH * 1.1;

  const v3x = cx - crownW * 0.08;
  const v3y = baseY - crownH * 0.45;
  const p4x = cx - crownW * 0.2;
  const p4y = baseY - crownH * 0.85;

  const v4x = cx - crownW * 0.28;
  const v4y = baseY - crownH * 0.35;
  const p5x = cx - crownW / 2;
  const p5y = baseY - crownH * 0.65;

  ctx.lineTo(p1x, p1y);
  ctx.lineTo(v1x, v1y);
  ctx.lineTo(p2x, p2y);
  ctx.lineTo(v2x, v2y);
  ctx.lineTo(pCenter, pCenterY);
  ctx.lineTo(v3x, v3y);
  ctx.lineTo(p4x, p4y);
  ctx.lineTo(v4x, v4y);
  ctx.lineTo(p5x, p5y);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  const jewels = [
    { x: p1x, y: p1y },
    { x: p2x, y: p2y },
    { x: pCenter, y: pCenterY },
    { x: p4x, y: p4y },
    { x: p5x, y: p5y },
  ];

  ctx.fillStyle = '#FFFFFF';
  ctx.shadowColor = '#FFFFFF';
  jewels.forEach((j) => {
    ctx.beginPath();
    ctx.arc(j.x, j.y, 2.5, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.restore();
}

/* =========================================================================
 * Center Frame Shapes & Inner Equalizer
 * ========================================================================= */
function drawCenterFrameAndInnerEqualizer(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  shape: string,
  showInnerEq: boolean,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  glowIntensity: number,
  activePulse: number
) {
  ctx.save();
  ctx.shadowBlur = 16 * glowIntensity;
  ctx.shadowColor = colorOne;
  ctx.strokeStyle = colorOne;
  ctx.lineWidth = 2.5;

  if (shape === 'spiky_ring') {
    ctx.beginPath();
    const spikes = 36;
    for (let s = 0; s < spikes; s++) {
      const angle = (s / spikes) * Math.PI * 2;
      const isTip = s % 2 === 0;
      const lvl = levels[s % levels.length] || 0.1;
      const r = isTip ? radius + lvl * 18 : radius - 4;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      if (s === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  } else if (shape === 'keyhole') {
    ctx.beginPath();
    const topRadius = radius * 0.95;
    const bottomTailY = cy + radius * 1.8;
    ctx.arc(cx, cy, topRadius, -Math.PI * 0.85, Math.PI * -0.15, false);
    ctx.quadraticCurveTo(cx + topRadius * 0.8, cy + radius * 0.8, cx, bottomTailY);
    ctx.quadraticCurveTo(cx - topRadius * 0.8, cy + radius * 0.8, cx - topRadius * Math.cos(Math.PI * 0.15), cy + topRadius * Math.sin(Math.PI * 0.15));
    ctx.stroke();

    const rays = 12;
    for (let r = 0; r < rays; r++) {
      const frac = r / (rays - 1 || 1);
      const xTop = cx - topRadius * 0.6 + frac * topRadius * 1.2;
      ctx.beginPath();
      ctx.moveTo(xTop, cy + 5);
      ctx.lineTo(cx, bottomTailY - 8);
      ctx.strokeStyle = hexToRgba(colorTwo, 0.4);
      ctx.lineWidth = 1;
      ctx.stroke();
    }
  } else if (shape === 'hexagon') {
    ctx.beginPath();
    for (let h = 0; h < 6; h++) {
      const angle = (h / 6) * Math.PI * 2 - Math.PI / 2;
      const x = cx + Math.cos(angle) * radius;
      const y = cy + Math.sin(angle) * radius;
      if (h === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = hexToRgba(colorTwo, 0.7);
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(cx, cy, radius - 5, 0, Math.PI * 2);
    ctx.stroke();
  }

  if (showInnerEq) {
    const barsCount = 7;
    const innerW = radius * 0.85;
    const barW = (innerW / barsCount) * 0.6;
    const startX = cx - innerW / 2;

    ctx.save();
    for (let b = 0; b < barsCount; b++) {
      const x = startX + b * (innerW / barsCount) + 2;
      const sample = levels[b * 4] || 0.1;
      const barH = Math.max(6, sample * (radius * 0.75));

      ctx.fillStyle = hexToRgba(colorOne, 0.9);
      ctx.shadowColor = colorOne;
      ctx.shadowBlur = 8;

      const r = Math.min(barW / 2, 4);
      drawRoundedRect(ctx, x, cy - barH / 2, barW, barH, r);
    }
    ctx.restore();
  }

  ctx.restore();
}

/* =========================================================================
 * Center Avatar/Logo Image on Waves
 * ========================================================================= */
function drawCenterImageOnWaves(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  centerImg: HTMLImageElement | null,
  sizePref: number,
  spin: boolean,
  border: boolean,
  blendMode: CanvasBlendMode = 'source-over',
  time: number,
  activePulse: number,
  colorOne: string,
  glowIntensity: number
) {
  if (!centerImg || !centerImg.complete || centerImg.naturalWidth <= 0) return;

  ctx.save();
  ctx.globalCompositeOperation = blendMode || 'source-over';
  const cx = width / 2;
  const cy = height / 2;
  const baseSize = Math.max(30, Math.min(Math.min(width, height) * 0.45, sizePref));
  const pulseScale = 1 + activePulse * 0.09;
  const radius = (baseSize / 2) * pulseScale;

  ctx.save();
  ctx.translate(cx, cy);
  if (spin) {
    ctx.rotate(time * 0.85);
  }

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();

  ctx.drawImage(centerImg, -radius, -radius, radius * 2, radius * 2);
  ctx.restore();

  if (border) {
    ctx.save();
    ctx.shadowBlur = 16 * glowIntensity;
    ctx.shadowColor = colorOne;
    ctx.strokeStyle = colorOne;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, radius - 3, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  ctx.restore();
}

/* =========================================================================
 * In-Canvas Text Overlays & Watermark (Synchronized Auto-Hide)
 * ========================================================================= */
function drawTextOverlays(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  title: string,
  artist: string,
  settings: VisualizerSettings,
  colorOne: string,
  colorTwo: string,
  shouldDrawTitle: boolean,
  textBlendMode: CanvasBlendMode = 'source-over'
) {
  const {
    showTrackTitle,
    showTrackArtist,
    showWatermark,
    customWatermarkText,
    textPosition,
    textGlow,
    textColor,
    textSize,
  } = settings;

  ctx.save();
  ctx.globalCompositeOperation = textBlendMode || 'source-over';
  ctx.textAlign = 'center';

  if (textGlow) {
    ctx.shadowBlur = 12;
    ctx.shadowColor = colorOne;
  } else {
    ctx.shadowBlur = 0;
  }

  const titleFontSize = textSize === 'small' ? 14 : textSize === 'large' ? 20 : 17;
  const artistFontSize = textSize === 'small' ? 10 : textSize === 'large' ? 13 : 11;

  let yPos = 36;
  if (textPosition === 'center') {
    yPos = height / 2 - (showTrackArtist ? 28 : 10);
  } else if (textPosition === 'bottom') {
    yPos = height - 52;
  }

  // Watermark (e.g. EGO_MUSIC7)
  if (showWatermark && customWatermarkText) {
    ctx.save();
    ctx.font = '900 18px Cairo, sans-serif';
    ctx.shadowBlur = 15;
    ctx.shadowColor = colorOne;

    const textGrad = ctx.createLinearGradient(width * 0.3, 0, width * 0.7, 0);
    textGrad.addColorStop(0, colorOne);
    textGrad.addColorStop(0.5, '#FFFFFF');
    textGrad.addColorStop(1, colorTwo);
    ctx.fillStyle = textGrad;
    ctx.fillText(customWatermarkText, width / 2, 28, width * 0.9);
    ctx.restore();
  }

  // Track Title & Artist (Follows shouldDrawTitle)
  if (shouldDrawTitle) {
    if (showTrackTitle && title) {
      ctx.font = `bold ${titleFontSize}px Cairo, sans-serif`;
      ctx.fillStyle = textColor || '#FFFFFF';
      ctx.fillText(title, width / 2, yPos, width * 0.88);
    }

    if (showTrackArtist && artist) {
      ctx.font = `600 ${artistFontSize}px Cairo, sans-serif`;
      ctx.fillStyle = colorOne;
      ctx.fillText(artist, width / 2, yPos + titleFontSize + 4, width * 0.85);
    }
  }

  ctx.restore();
}

/* =========================================================================
 * Visualizer Modes Implementations
 * ========================================================================= */
function renderMirrorVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  peaks: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  barSpacingPref: number,
  roundness: number,
  glowIntensity: number,
  showPeakCaps: boolean,
  fillOpacity: number
) {
  const centerY = height / 2;
  const count = levels.length;
  if (count === 0) return;

  const actualBarWidth = Math.min(
    barWidthPref,
    Math.max(1.0, (width - (count - 1) * barSpacingPref) / count)
  );
  const totalWidth = count * actualBarWidth + (count - 1) * barSpacingPref;
  const startX = Math.max(0, (width - totalWidth) / 2);

  ctx.save();
  ctx.shadowBlur = 14 * glowIntensity;

  for (let i = 0; i < count; i++) {
    const fraction = count > 1 ? i / (count - 1) : 0.5;
    const barColor = lerpColor(colorOne, colorTwo, fraction);
    const level = Math.max(0.03, Math.min(1.0, levels[i]));
    const x = startX + i * (actualBarWidth + barSpacingPref);
    const barHeight = Math.max(4.0, level * height * 0.82);
    const halfHeight = Math.max(2.0, barHeight / 2);

    ctx.fillStyle = hexToRgba(barColor, Math.max(0.2, fillOpacity + 0.3));
    ctx.shadowColor = barColor;

    const r = Math.min(actualBarWidth / 2, roundness);
    drawRoundedRect(ctx, x, centerY - halfHeight, actualBarWidth, halfHeight, r);
    drawRoundedRect(ctx, x, centerY, actualBarWidth, halfHeight, r);

    if (showPeakCaps && peaks[i]) {
      const peakHalf = Math.max(2.0, (peaks[i] * height * 0.82) / 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = '#FFFFFF';
      ctx.fillRect(x, centerY - peakHalf - 2, actualBarWidth, 2);
      ctx.fillRect(x, centerY + peakHalf, actualBarWidth, 2);
    }
  }

  ctx.restore();
}

function renderClassicBarsVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  peaks: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  barSpacingPref: number,
  roundness: number,
  glowIntensity: number,
  showPeakCaps: boolean,
  fillOpacity: number
) {
  const count = levels.length;
  if (count === 0) return;

  const actualBarWidth = Math.min(
    barWidthPref,
    Math.max(1.0, (width - (count - 1) * barSpacingPref) / count)
  );
  const totalWidth = count * actualBarWidth + (count - 1) * barSpacingPref;
  const startX = Math.max(0, (width - totalWidth) / 2);
  const baseline = height - 12;

  ctx.save();
  ctx.shadowBlur = 14 * glowIntensity;

  for (let i = 0; i < count; i++) {
    const fraction = count > 1 ? i / (count - 1) : 0.5;
    const barColor = lerpColor(colorOne, colorTwo, fraction);
    const level = Math.max(0.03, Math.min(1.0, levels[i]));
    const x = startX + i * (actualBarWidth + barSpacingPref);
    const barHeight = Math.max(4.0, level * (height * 0.78));

    const grad = ctx.createLinearGradient(x, baseline, x, baseline - barHeight);
    grad.addColorStop(0, hexToRgba(barColor, fillOpacity * 0.7));
    grad.addColorStop(1, barColor);

    ctx.fillStyle = grad;
    ctx.shadowColor = barColor;

    const r = Math.min(actualBarWidth / 2, roundness);
    drawRoundedRect(ctx, x, baseline - barHeight, actualBarWidth, barHeight, r);

    if (showPeakCaps && peaks[i]) {
      const peakY = baseline - Math.max(4.0, peaks[i] * (height * 0.78)) - 4;
      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = '#FFFFFF';
      ctx.fillRect(x, peakY, actualBarWidth, 2.5);
    }
  }

  ctx.restore();
}

function renderSmoothWaveVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  strokeThickness: number,
  glowIntensity: number,
  fillOpacity: number,
  time: number
) {
  const count = levels.length;
  if (count < 2) return;

  const centerY = height / 2;
  const step = width / (count - 1);

  ctx.save();
  ctx.shadowBlur = 16 * glowIntensity;
  ctx.shadowColor = colorOne;

  const points: { x: number; y: number }[] = [];
  for (let i = 0; i < count; i++) {
    const x = i * step;
    const wobble = Math.sin(time * 2.0 + i * 0.4) * 6;
    const amp = levels[i] * (height * 0.42);
    const y = centerY - amp + wobble;
    points.push({ x, y });
  }

  const fillGrad = ctx.createLinearGradient(0, centerY - height * 0.4, 0, height);
  fillGrad.addColorStop(0, hexToRgba(colorOne, fillOpacity * 0.8));
  fillGrad.addColorStop(0.5, hexToRgba(colorTwo, fillOpacity * 0.4));
  fillGrad.addColorStop(1, 'transparent');

  ctx.beginPath();
  ctx.moveTo(0, height);
  ctx.lineTo(points[0].x, points[0].y);

  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const midX = (p0.x + p1.x) / 2;
    const midY = (p0.y + p1.y) / 2;
    ctx.quadraticCurveTo(p0.x, p0.y, midX, midY);
  }
  ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
  ctx.lineTo(width, height);
  ctx.closePath();
  ctx.fillStyle = fillGrad;
  ctx.fill();

  const strokeGrad = ctx.createLinearGradient(0, 0, width, 0);
  strokeGrad.addColorStop(0, colorOne);
  strokeGrad.addColorStop(0.5, colorTwo);
  strokeGrad.addColorStop(1, colorOne);

  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const midX = (p0.x + p1.x) / 2;
    const midY = (p0.y + p1.y) / 2;
    ctx.quadraticCurveTo(p0.x, p0.y, midX, midY);
  }
  ctx.lineTo(points[points.length - 1].x, points[points.length - 1].y);
  ctx.strokeStyle = strokeGrad;
  ctx.lineWidth = Math.max(2, strokeThickness);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(0, centerY);
  for (let i = 0; i < count; i++) {
    const x = i * step;
    const amp = levels[i] * (height * 0.28);
    const y = centerY + amp;
    ctx.lineTo(x, y);
  }
  ctx.strokeStyle = hexToRgba(colorTwo, 0.4);
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.restore();
}

function renderRadialVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  glowIntensity: number,
  activePulse: number,
  time: number,
  frameShape: string
) {
  const cx = width / 2;
  const cy = height / 2;
  const baseRadius = Math.min(width, height) * (0.2 + activePulse * 0.05);
  const maxBarLength = Math.min(width, height) * 0.26;
  const count = levels.length;

  ctx.save();
  ctx.shadowBlur = 14 * glowIntensity;

  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2 - Math.PI / 2 + time * 0.2;
    const fraction = i / count;
    const barColor = lerpColor(colorOne, colorTwo, fraction);
    const level = Math.max(0.04, Math.min(1.0, levels[i]));
    const barLength = Math.max(3, level * maxBarLength);

    const x1 = cx + Math.cos(angle) * baseRadius;
    const y1 = cy + Math.sin(angle) * baseRadius;
    const x2 = cx + Math.cos(angle) * (baseRadius + barLength);
    const y2 = cy + Math.sin(angle) * (baseRadius + barLength);

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = barColor;
    ctx.shadowColor = barColor;
    ctx.lineWidth = Math.max(1.5, Math.min(barWidthPref, (Math.PI * 2 * baseRadius) / (count * 1.3)));
    ctx.lineCap = 'round';
    ctx.stroke();
  }

  ctx.restore();
}

function renderSpiralVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  glowIntensity: number,
  time: number
) {
  const cx = width / 2;
  const cy = height / 2;
  const count = levels.length;
  const maxRadius = Math.min(width, height) * 0.44;

  ctx.save();
  ctx.shadowBlur = 14 * glowIntensity;

  for (let i = 0; i < count; i++) {
    const fraction = i / (count - 1 || 1);
    const barColor = lerpColor(colorOne, colorTwo, fraction);
    const level = Math.max(0.04, Math.min(1.0, levels[i]));

    const turns = 3.2;
    const angle = fraction * Math.PI * 2 * turns + time * 0.5;
    const radius = 18 + Math.pow(fraction, 1.2) * (maxRadius - 18);
    const spike = level * 28;

    const x1 = cx + Math.cos(angle) * radius;
    const y1 = cy + Math.sin(angle) * radius;
    const x2 = cx + Math.cos(angle) * (radius + spike);
    const y2 = cy + Math.sin(angle) * (radius + spike);

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = barColor;
    ctx.shadowColor = barColor;
    ctx.lineWidth = Math.max(1.5, Math.min(6, barWidthPref * 0.8));
    ctx.lineCap = 'round';
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(x2, y2, Math.max(1.5, level * 3.5), 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

function renderOscilloscopeVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  glowIntensity: number,
  time: number
) {
  const centerY = height / 2;
  const count = levels.length;

  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.lineWidth = 1;
  ctx.setLineDash([4, 4]);
  ctx.beginPath();
  ctx.moveTo(0, centerY);
  ctx.lineTo(width, centerY);
  ctx.moveTo(width / 2, 0);
  ctx.lineTo(width / 2, height);
  ctx.stroke();
  ctx.setLineDash([]);

  ctx.shadowBlur = 18 * glowIntensity;
  ctx.shadowColor = colorOne;

  ctx.beginPath();
  const step = width / (count - 1 || 1);
  for (let i = 0; i < count; i++) {
    const x = i * step;
    const sign = i % 2 === 0 ? 1 : -1;
    const freqOsc = Math.sin(time * 4.0 + i * 0.45) * 8;
    const amp = levels[i] * (height * 0.38) * sign;
    const y = centerY + amp + freqOsc;

    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = colorOne;
  ctx.lineWidth = Math.max(2, barWidthPref);
  ctx.lineJoin = 'round';
  ctx.stroke();

  ctx.beginPath();
  for (let i = 0; i < count; i++) {
    const x = i * step;
    const sign = i % 2 === 0 ? -1 : 1;
    const freqOsc = Math.sin(time * 3.2 - i * 0.3) * 6;
    const amp = levels[i] * (height * 0.22) * sign;
    const y = centerY + amp + freqOsc;

    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = hexToRgba(colorTwo, 0.5);
  ctx.lineWidth = Math.max(1, barWidthPref * 0.6);
  ctx.stroke();

  ctx.restore();
}

function renderCyber3DGridVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  glowIntensity: number,
  fillOpacity: number,
  time: number
) {
  const count = levels.length;
  const layers = 3;
  const step = width / (count - 1 || 1);

  ctx.save();
  ctx.shadowBlur = 12 * glowIntensity;

  for (let layer = layers - 1; layer >= 0; layer--) {
    const layerOffset = (layer / layers) * (height * 0.24);
    const layerBaseY = height * 0.55 + layerOffset;
    const layerColor = lerpColor(colorTwo, colorOne, layer / (layers - 1 || 1));
    const delay = layer * 0.5;

    ctx.beginPath();
    ctx.moveTo(0, layerBaseY);

    for (let i = 0; i < count; i++) {
      const x = i * step;
      const wobble = Math.sin(time * 2.2 - i * 0.25 + delay) * 4;
      const amp = levels[i] * (height * 0.32) * (1 - layer * 0.2);
      const y = layerBaseY - amp + wobble;
      ctx.lineTo(x, y);
    }

    ctx.strokeStyle = layerColor;
    ctx.shadowColor = layerColor;
    ctx.lineWidth = Math.max(1.8, barWidthPref * (1 - layer * 0.2));
    ctx.stroke();

    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fillStyle = hexToRgba(layerColor, fillOpacity * (0.4 - layer * 0.1));
    ctx.fill();
  }

  ctx.restore();
}

function renderStarburstVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  glowIntensity: number,
  activePulse: number,
  time: number
) {
  const cx = width / 2;
  const cy = height / 2;
  const ringRadius = Math.min(width, height) * (0.24 + activePulse * 0.08);
  const count = levels.length;

  ctx.save();
  ctx.shadowBlur = 16 * glowIntensity;

  ctx.beginPath();
  ctx.arc(cx, cy, ringRadius, 0, Math.PI * 2);
  ctx.strokeStyle = hexToRgba(colorOne, 0.45);
  ctx.lineWidth = 1.5;
  ctx.stroke();

  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2 + time * 0.2;
    const fraction = i / count;
    const barColor = lerpColor(colorOne, colorTwo, fraction);
    const level = Math.max(0.04, Math.min(1.0, levels[i]));

    const outLength = level * (Math.min(width, height) * 0.22);
    const inLength = level * (Math.min(width, height) * 0.1);

    const xIn = cx + Math.cos(angle) * (ringRadius - inLength);
    const yIn = cy + Math.sin(angle) * (ringRadius - inLength);
    const xOut = cx + Math.cos(angle) * (ringRadius + outLength);
    const yOut = cy + Math.sin(angle) * (ringRadius + outLength);

    ctx.beginPath();
    ctx.moveTo(xIn, yIn);
    ctx.lineTo(xOut, yOut);
    ctx.strokeStyle = barColor;
    ctx.shadowColor = barColor;
    ctx.lineWidth = Math.max(1.5, Math.min(5, barWidthPref));
    ctx.lineCap = 'round';
    ctx.stroke();

    if (level > 0.45) {
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(xOut, yOut, 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

function renderCapsulesVisualizer(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  levels: number[],
  peaks: number[],
  colorOne: string,
  colorTwo: string,
  barWidthPref: number,
  barSpacingPref: number,
  roundness: number,
  glowIntensity: number,
  fillOpacity: number
) {
  const count = levels.length;
  if (count === 0) return;

  const actualBarWidth = Math.min(
    barWidthPref * 1.5,
    Math.max(2.0, (width - (count - 1) * barSpacingPref) / count)
  );
  const totalWidth = count * actualBarWidth + (count - 1) * barSpacingPref;
  const startX = Math.max(0, (width - totalWidth) / 2);
  const centerY = height / 2;

  ctx.save();
  ctx.shadowBlur = 14 * glowIntensity;

  for (let i = 0; i < count; i++) {
    const fraction = count > 1 ? i / (count - 1) : 0.5;
    const barColor = lerpColor(colorOne, colorTwo, fraction);
    const level = Math.max(0.04, Math.min(1.0, levels[i]));
    const x = startX + i * (actualBarWidth + barSpacingPref);

    const segments = 6;
    const activeSegments = Math.ceil(level * segments);
    const segHeight = Math.max(3.0, (height * 0.36) / segments);

    for (let s = 0; s < segments; s++) {
      const isActive = s < activeSegments;
      const isPeak = peaks[i] && Math.floor(peaks[i] * segments) === s;

      const topY = centerY - (s + 1) * (segHeight + 2);
      const bottomY = centerY + s * (segHeight + 2);

      const color = isActive
        ? barColor
        : isPeak
        ? '#FFFFFF'
        : hexToRgba(barColor, fillOpacity * 0.3);

      ctx.fillStyle = color;
      ctx.shadowColor = isActive ? barColor : 'transparent';

      const r = Math.min(actualBarWidth / 2, Math.max(2, roundness));
      drawRoundedRect(ctx, x, topY, actualBarWidth, segHeight, r);
      drawRoundedRect(ctx, x, bottomY, actualBarWidth, segHeight, r);
    }
  }

  ctx.restore();
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  if (w <= 0 || h <= 0) return;
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  ctx.fill();
}
