/**
 * Procedural Web Audio synthesizer that creates rich, high-fidelity royalty-free tracks
 * entirely in-browser. Zero external network requests, zero CORS issues, instant playback.
 */

// Helper to write an AudioBuffer into a WAV Blob
export function bufferToWaveBlob(abuffer: AudioBuffer): Blob {
  const numOfChan = abuffer.numberOfChannels;
  const length = abuffer.length * numOfChan * 2 + 44;
  const outBuffer = new ArrayBuffer(length);
  const view = new DataView(outBuffer);
  const channels: Float32Array[] = [];
  let sampleRate = abuffer.sampleRate;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    view.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: number) {
    view.setUint32(pos, data, true);
    pos += 4;
  }

  // RIFF identifier
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"

  // FMT sub-chunk
  setUint32(0x20746d66); // "fmt "
  setUint32(16); // subchunk1size (16 for PCM)
  setUint16(1); // audio format (1 = PCM)
  setUint16(numOfChan);
  setUint32(sampleRate);
  setUint32(sampleRate * 2 * numOfChan); // byte rate
  setUint16(numOfChan * 2); // block align
  setUint16(16); // bits per sample

  // data sub-chunk
  setUint32(0x61746164); // "data"
  setUint32(length - pos - 4);

  for (let i = 0; i < abuffer.numberOfChannels; i++) {
    channels.push(abuffer.getChannelData(i));
  }

  while (pos < length) {
    for (let i = 0; i < numOfChan; i++) {
      let sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      view.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([outBuffer], { type: 'audio/wav' });
}

export interface DemoTrack {
  id: string;
  title: string;
  artist: string;
  genre: string;
  duration: number; // in seconds
  bpm: number;
  generator: (ctx: AudioContext, durationSec: number) => AudioBuffer;
}

export const DEMO_TRACKS: DemoTrack[] = [
  {
    id: 'cyber-pulse',
    title: 'نبضات نيون فضائية (Cyber Pulse)',
    artist: 'أطياف النيون',
    genre: 'سينثويف إلكتروني',
    duration: 32,
    bpm: 120,
    generator: generateCyberPulseBuffer,
  },
  {
    id: 'oriental-neon',
    title: 'تقاسيم ليلية نيون (Midnight Oud)',
    artist: 'أوتار الشرق الرقمية',
    genre: 'موسيقى شرقية معاصرة',
    duration: 30,
    bpm: 96,
    generator: generateOrientalNeonBuffer,
  },
  {
    id: 'deep-cosmic',
    title: 'ألحان الفضاء الهادئة (Cosmic Lofi)',
    artist: 'موجات الاسترخاء',
    genre: 'لوفاي هادئ',
    duration: 32,
    bpm: 84,
    generator: generateCosmicLofiBuffer,
  },
  {
    id: 'electro-trance',
    title: 'إيقاع الطيف الإلكتروني (Neon Trance)',
    artist: 'محطة الترددات',
    genre: 'ترانس وإلكترودانس',
    duration: 32,
    bpm: 128,
    generator: generateElectroTranceBuffer,
  },
];

// 1. Cyber Pulse generator (Synthwave with driving bass, synth arpeggios, kicks, hats)
function generateCyberPulseBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * durationSec);
  const buffer = ctx.createBuffer(2, length, sampleRate);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  const bpm = 120;
  const beatDuration = 60 / bpm;
  const sixteenth = beatDuration / 4;

  // Scale: Minor pentatonic / Dorian in D (D3=146.83, F3=174.61, G3=196, A3=220, C4=261.63, D4=293.66, F4=349.23, A4=440)
  const bassNotes = [73.42, 73.42, 87.31, 98.0, 73.42, 73.42, 110.0, 98.0]; // D2, D2, F2, G2, D2, D2, A2, G2
  const arpNotes = [293.66, 349.23, 440.0, 523.25, 587.33, 440.0, 349.23, 293.66];

  for (let i = 0; i < length; i++) {
    const t = i / sampleRate;
    const currentBeat = t / beatDuration;
    const beatFraction = currentBeat % 1;
    const sixteenthIndex = Math.floor(t / sixteenth);

    let sampleL = 0;
    let sampleR = 0;

    // --- Kick Drum on beats 0, 1, 2, 3 ---
    const kickTime = (t % beatDuration);
    if (kickTime < 0.25) {
      const kickFreq = 140 * Math.exp(-kickTime * 22) + 42;
      const kickEnv = Math.exp(-kickTime * 14);
      const kick = Math.sin(2 * Math.PI * kickFreq * kickTime) * kickEnv * 0.65;
      sampleL += kick;
      sampleR += kick;
    }

    // --- Snare / Clack on beats 2 and 4 (beat index 1 and 3) ---
    const halfMeasureTime = (t % (beatDuration * 2));
    if (halfMeasureTime >= beatDuration && halfMeasureTime < beatDuration + 0.28) {
      const snareT = halfMeasureTime - beatDuration;
      const noise = (Math.random() * 2 - 1) * Math.exp(-snareT * 18) * 0.28;
      const body = Math.sin(2 * Math.PI * 185 * snareT) * Math.exp(-snareT * 25) * 0.3;
      sampleL += noise + body;
      sampleR += noise * 0.9 + body;
    }

    // --- Hi-Hats on 16ths ---
    const hatT = t % (sixteenth / 2);
    if (hatT < 0.05) {
      const hatEnv = Math.exp(-hatT * 60);
      const hatNoise = (Math.random() * 2 - 1) * hatEnv * 0.12;
      sampleL += hatNoise * 0.7;
      sampleR += hatNoise * 1.1;
    }

    // --- Bassline (8th notes) ---
    const eighthIndex = Math.floor(t / (beatDuration / 2)) % bassNotes.length;
    const bassNoteT = (t % (beatDuration / 2));
    const bassFreq = bassNotes[eighthIndex];
    if (bassNoteT < (beatDuration / 2) * 0.85) {
      const bassEnv = Math.exp(-bassNoteT * 6);
      // Saw-like rich harmonics
      const bassOsc = 
        Math.sin(2 * Math.PI * bassFreq * t) * 0.4 +
        Math.sin(2 * Math.PI * bassFreq * 2 * t) * 0.2 +
        Math.sin(2 * Math.PI * bassFreq * 3 * t) * 0.08;
      sampleL += bassOsc * bassEnv * 0.45;
      sampleR += bassOsc * bassEnv * 0.45;
    }

    // --- Synth Arpeggio (16th notes) ---
    const arpNoteT = (t % sixteenth);
    const arpFreq = arpNotes[sixteenthIndex % arpNotes.length];
    if (arpNoteT < sixteenth * 0.8) {
      const arpEnv = Math.exp(-arpNoteT * 10);
      // Dual detuned oscillator for lush stereo chorus
      const oscL = Math.sin(2 * Math.PI * arpFreq * t) + 0.4 * Math.sin(2 * Math.PI * (arpFreq * 2.01) * t);
      const oscR = Math.sin(2 * Math.PI * (arpFreq * 1.006) * t) + 0.4 * Math.sin(2 * Math.PI * (arpFreq * 1.99) * t);
      sampleL += oscL * arpEnv * 0.22;
      sampleR += oscR * arpEnv * 0.22;
    }

    // --- Atmosphere Pad (slow evolving chord) ---
    const chordT = (t % (beatDuration * 8)) / (beatDuration * 8);
    const padGain = Math.sin(chordT * Math.PI) * 0.16;
    const padFreqs = [293.66, 369.99, 440.0, 587.33];
    let pad = 0;
    for (const pf of padFreqs) {
      pad += Math.sin(2 * Math.PI * pf * t + Math.sin(t * 1.5) * 0.3);
    }
    sampleL += (pad / padFreqs.length) * padGain;
    sampleR += (pad / padFreqs.length) * padGain * 0.95;

    // Soft limiter / saturation
    left[i] = Math.tanh(sampleL * 0.95);
    right[i] = Math.tanh(sampleR * 0.95);
  }

  return buffer;
}

// 2. Oriental Neon (Quarter-tone Bayati / Hijaz feel with digital pluck and ambient frame drum)
function generateOrientalNeonBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * durationSec);
  const buffer = ctx.createBuffer(2, length, sampleRate);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  const bpm = 96;
  const beatDuration = 60 / bpm;

  // D Bayati / Rast notes: D4, E half-flat (approx 311.1 * 0.97 = 302Hz), F4, G4, A4, Bb4, C5, D5
  const melodyNotes = [
    293.66, 305.0, 349.23, 392.0, 440.0, 392.0, 349.23, 305.0,
    293.66, 349.23, 392.0, 440.0, 466.16, 440.0, 392.0, 293.66,
  ];

  for (let i = 0; i < length; i++) {
    const t = i / sampleRate;
    let sampleL = 0;
    let sampleR = 0;

    // --- Oriental Percussion (Duhulla / Dumbek Doum on 1, Tek on 3 & 4) ---
    const barTime = t % (beatDuration * 4);
    // Doum at 0: deep bass resonance
    if (barTime < 0.35) {
      const doumFreq = 120 * Math.exp(-barTime * 15) + 55;
      const doum = Math.sin(2 * Math.PI * doumFreq * barTime) * Math.exp(-barTime * 8) * 0.7;
      sampleL += doum;
      sampleR += doum;
    }
    // Tek at beat 2 (beatDuration * 2) and beat 3.5
    const tek1Time = barTime - (beatDuration * 2);
    if (tek1Time > 0 && tek1Time < 0.12) {
      const tek = ((Math.random() * 2 - 1) * 0.3 + Math.sin(2 * Math.PI * 480 * tek1Time) * 0.5) * Math.exp(-tek1Time * 35);
      sampleL += tek * 0.8;
      sampleR += tek * 1.1;
    }
    const tek2Time = barTime - (beatDuration * 3.5);
    if (tek2Time > 0 && tek2Time < 0.1) {
      const tek = ((Math.random() * 2 - 1) * 0.25 + Math.sin(2 * Math.PI * 620 * tek2Time) * 0.4) * Math.exp(-tek2Time * 40);
      sampleL += tek * 1.1;
      sampleR += tek * 0.75;
    }

    // --- Deep Drone (D2 & A2) ---
    const drone = (Math.sin(2 * Math.PI * 73.42 * t) * 0.35 + Math.sin(2 * Math.PI * 110.0 * t) * 0.15) * 0.45;
    sampleL += drone;
    sampleR += drone;

    // --- Digital Oud / Pluck Melody ---
    const noteStep = beatDuration;
    const noteIndex = Math.floor(t / noteStep) % melodyNotes.length;
    const noteT = t % noteStep;
    const freq = melodyNotes[noteIndex];

    if (noteT < noteStep * 0.88) {
      // Karplus-Strong / pluck emulation using decaying harmonics
      const env = Math.exp(-noteT * 7.5);
      const pluck = 
        Math.sin(2 * Math.PI * freq * t) * 0.5 +
        Math.sin(2 * Math.PI * freq * 2 * t) * 0.3 * Math.exp(-noteT * 12) +
        Math.sin(2 * Math.PI * freq * 3 * t) * 0.2 * Math.exp(-noteT * 18) +
        Math.sin(2 * Math.PI * freq * 4 * t) * 0.15 * Math.exp(-noteT * 24);
      
      // Delay / reverb reflection
      const delayTime = 0.22;
      const delayedT = t - delayTime;
      const delayedPluck = delayedT > 0 ? Math.sin(2 * Math.PI * freq * delayedT) * Math.exp(-((delayedT % noteStep)) * 8) * 0.2 : 0;

      sampleL += pluck * env * 0.45 + delayedPluck * 0.25;
      sampleR += pluck * env * 0.4 + delayedPluck * 0.35;
    }

    left[i] = Math.tanh(sampleL * 0.9);
    right[i] = Math.tanh(sampleR * 0.9);
  }

  return buffer;
}

// 3. Cosmic Lofi (Warm 7th chords, relaxed vinyl noise, deep smooth sub)
function generateCosmicLofiBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * durationSec);
  const buffer = ctx.createBuffer(2, length, sampleRate);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  const bpm = 84;
  const beatDuration = 60 / bpm;
  const barDuration = beatDuration * 4;

  // Lofi chords: Fmaj7 -> Em7 -> Dm7 -> Cmaj7
  const chords = [
    [174.61, 220.0, 261.63, 329.63], // Fmaj7
    [164.81, 196.0, 246.94, 293.66], // Em7
    [146.83, 174.61, 220.0, 261.63], // Dm7
    [130.81, 164.81, 196.0, 246.94], // Cmaj7
  ];

  for (let i = 0; i < length; i++) {
    const t = i / sampleRate;
    let sampleL = 0;
    let sampleR = 0;

    // Vinyl crackle / hiss
    const vinyl = (Math.random() * 2 - 1) * 0.015 * (Math.random() > 0.985 ? 4.0 : 0.8);
    sampleL += vinyl;
    sampleR += vinyl;

    // Soft lofi kick on beat 0 and beat 2.5
    const barT = t % barDuration;
    const kick1T = barT;
    if (kick1T < 0.25) {
      const kick = Math.sin(2 * Math.PI * (90 * Math.exp(-kick1T * 20) + 40) * kick1T) * Math.exp(-kick1T * 9) * 0.55;
      sampleL += kick;
      sampleR += kick;
    }
    const kick2T = barT - (beatDuration * 2.5);
    if (kick2T > 0 && kick2T < 0.2) {
      const kick = Math.sin(2 * Math.PI * (85 * Math.exp(-kick2T * 20) + 38) * kick2T) * Math.exp(-kick2T * 9) * 0.45;
      sampleL += kick;
      sampleR += kick;
    }

    // Warm rimshot snare on beat 2
    const snareT = barT - (beatDuration * 2);
    if (snareT > 0 && snareT < 0.18) {
      const rim = (Math.sin(2 * Math.PI * 330 * snareT) * 0.4 + (Math.random() * 2 - 1) * 0.3) * Math.exp(-snareT * 22);
      sampleL += rim * 0.35;
      sampleR += rim * 0.35;
    }

    // Chords (warm filtered electric piano)
    const chordIndex = Math.floor(t / barDuration) % chords.length;
    const chord = chords[chordIndex];
    const chordT = barT / barDuration;
    const chordEnv = Math.sin(chordT * Math.PI * 0.9 + 0.1) * 0.24;

    for (let c = 0; c < chord.length; c++) {
      const freq = chord[c];
      // subtle tremolo
      const tremolo = 1 + 0.08 * Math.sin(2 * Math.PI * 3.5 * t);
      const tone = Math.sin(2 * Math.PI * freq * t) + 0.25 * Math.sin(2 * Math.PI * freq * 2 * t);
      sampleL += (tone / chord.length) * chordEnv * tremolo;
      sampleR += (tone / chord.length) * chordEnv * (1 / tremolo);
    }

    // Sub bass
    const rootFreq = chord[0] / 2;
    const sub = Math.sin(2 * Math.PI * rootFreq * t) * 0.35;
    sampleL += sub;
    sampleR += sub;

    left[i] = Math.tanh(sampleL * 0.95);
    right[i] = Math.tanh(sampleR * 0.95);
  }

  return buffer;
}

// 4. Electro Trance (Energetic, high frequency spectrum, punchy drop)
function generateElectroTranceBuffer(ctx: AudioContext, durationSec: number): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * durationSec);
  const buffer = ctx.createBuffer(2, length, sampleRate);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  const bpm = 128;
  const beatDuration = 60 / bpm;
  const sixteenth = beatDuration / 4;

  const notes = [440, 493.88, 523.25, 659.25, 587.33, 523.25, 493.88, 440];

  for (let i = 0; i < length; i++) {
    const t = i / sampleRate;
    let sampleL = 0;
    let sampleR = 0;

    // 4-on-the-floor Punchy Kick
    const kickTime = t % beatDuration;
    if (kickTime < 0.22) {
      const kickFreq = 160 * Math.exp(-kickTime * 28) + 48;
      const kick = Math.sin(2 * Math.PI * kickFreq * kickTime) * Math.exp(-kickTime * 12) * 0.75;
      sampleL += kick;
      sampleR += kick;
    }

    // Offbeat open hi-hat
    const offbeatTime = (t + beatDuration * 0.5) % beatDuration;
    if (offbeatTime < 0.14) {
      const hat = (Math.random() * 2 - 1) * Math.exp(-offbeatTime * 30) * 0.22;
      sampleL += hat * 0.8;
      sampleR += hat * 1.1;
    }

    // Rolling bassline (16th notes with sidechain ducking)
    const sixteenthT = t % sixteenth;
    const ducking = Math.min(1, (kickTime / beatDuration) * 1.8);
    const bassFreq = 55.0; // A1
    const bass = (Math.sin(2 * Math.PI * bassFreq * t) + 0.5 * Math.sin(2 * Math.PI * bassFreq * 2 * t)) * Math.exp(-sixteenthT * 12);
    sampleL += bass * 0.45 * ducking;
    sampleR += bass * 0.45 * ducking;

    // Euphoric Supersaw Lead
    const noteIdx = Math.floor(t / sixteenth) % notes.length;
    const leadFreq = notes[noteIdx];
    const leadT = sixteenthT;
    const leadEnv = Math.exp(-leadT * 8);

    // 3 detuned saws for wide stereo supersaw
    const saw1 = (2 * ((leadFreq * t) % 1) - 1);
    const saw2 = (2 * ((leadFreq * 1.008 * t) % 1) - 1);
    const saw3 = (2 * ((leadFreq * 0.992 * t) % 1) - 1);

    const supersawL = (saw1 * 0.5 + saw2 * 0.5) * leadEnv * 0.22 * ducking;
    const supersawR = (saw1 * 0.5 + saw3 * 0.5) * leadEnv * 0.22 * ducking;

    sampleL += supersawL;
    sampleR += supersawR;

    left[i] = Math.tanh(sampleL * 0.95);
    right[i] = Math.tanh(sampleR * 0.95);
  }

  return buffer;
}
