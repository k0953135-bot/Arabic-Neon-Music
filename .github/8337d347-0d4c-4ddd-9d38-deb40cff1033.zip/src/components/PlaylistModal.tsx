import React, { useRef } from 'react';
import { Track, Palette } from '../types';
import { X, Music, Play, Pause, Upload, ListMusic, Sparkles, Clock } from 'lucide-react';

interface PlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  playlist: Track[];
  currentTrackId: string;
  isPlaying: boolean;
  onSelectTrack: (track: Track) => void;
  onUploadFiles: (files: FileList) => void;
  currentPalette: Palette;
}

function formatDuration(sec: number): string {
  const mins = Math.floor(sec / 60);
  const secs = Math.floor(sec % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

export const PlaylistModal: React.FC<PlaylistModalProps> = ({
  isOpen,
  onClose,
  playlist,
  currentTrackId,
  isPlaying,
  onSelectTrack,
  onUploadFiles,
  currentPalette,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUploadFiles(e.target.files);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-sm transition-opacity">
      <div
        className="w-full max-w-lg bg-[#141722] border border-white/10 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col animate-in fade-in slide-in-from-bottom-6 duration-200"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div
              className="p-2 rounded-xl"
              style={{ backgroundColor: `${currentPalette.colorOne}20`, color: currentPalette.colorOne }}
            >
              <ListMusic className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">قائمة المقاطع الصوتية</h2>
              <p className="text-xs text-white/50">{playlist.length} مقاطع متوفرة للتشغيل</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Action Strip */}
        <div className="p-4 bg-[#10131D] border-b border-white/5 flex items-center justify-between gap-3">
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            multiple
            className="hidden"
            onChange={handleFileChange}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 py-2.5 px-4 rounded-xl border border-dashed flex items-center justify-center gap-2 text-xs font-semibold transition-all hover:bg-white/5"
            style={{
              borderColor: `${currentPalette.colorOne}60`,
              color: currentPalette.colorOne,
            }}
          >
            <Upload className="w-4 h-4" />
            <span>إضافة ملفات صوتية من جهازك</span>
          </button>
        </div>

        {/* Playlist Items */}
        <div className="p-4 space-y-2 overflow-y-auto custom-scrollbar flex-1">
          {playlist.map((track, idx) => {
            const isCurrent = track.id === currentTrackId;

            return (
              <div
                key={track.id}
                onClick={() => onSelectTrack(track)}
                className={`group flex items-center justify-between p-3.5 rounded-2xl cursor-pointer transition-all border ${
                  isCurrent
                    ? 'border-transparent shadow-lg'
                    : 'border-white/5 bg-[#10131D]/60 hover:bg-white/5 hover:border-white/10'
                }`}
                style={
                  isCurrent
                    ? {
                        backgroundColor: `${currentPalette.colorOne}18`,
                        borderColor: `${currentPalette.colorOne}50`,
                      }
                    : {}
                }
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  {/* Play icon / Track index */}
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105"
                    style={{
                      background: isCurrent
                        ? `linear-gradient(135deg, ${currentPalette.colorOne}, ${currentPalette.colorTwo})`
                        : 'rgba(255, 255, 255, 0.05)',
                      color: isCurrent ? '#000' : 'rgba(255, 255, 255, 0.6)',
                    }}
                  >
                    {isCurrent && isPlaying ? (
                      <Pause className="w-4 h-4 fill-current" />
                    ) : (
                      <Play className="w-4 h-4 fill-current translate-x-[-1px]" />
                    )}
                  </div>

                  {/* Title & metadata */}
                  <div className="min-w-0">
                    <h3
                      className={`text-sm font-bold truncate ${
                        isCurrent ? 'text-white' : 'text-white/85 group-hover:text-white'
                      }`}
                      style={isCurrent ? { color: currentPalette.colorOne } : {}}
                    >
                      {track.title}
                    </h3>
                    <div className="flex items-center gap-2 text-[11px] text-white/50 mt-0.5">
                      <span>{track.artist}</span>
                      <span>·</span>
                      <span className="truncate">{track.genre}</span>
                      {track.sourceType === 'procedural' && (
                        <>
                          <span>·</span>
                          <span
                            className="inline-flex items-center gap-0.5 font-medium"
                            style={{ color: currentPalette.colorTwo }}
                          >
                            <Sparkles className="w-2.5 h-2.5" />
                            مدمج
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Duration */}
                <div className="flex items-center gap-1.5 text-xs font-mono text-white/50 shrink-0 mr-2">
                  <Clock className="w-3 h-3 text-white/30" />
                  <span>{formatDuration(track.duration)}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#10131D]/80 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl text-xs font-bold text-white/80 hover:text-white bg-white/10 hover:bg-white/15 transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
