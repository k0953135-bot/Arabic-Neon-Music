export type VisualizerStyle =
  | 'mirror'
  | 'bars'
  | 'wave'
  | 'radial'
  | 'spiral'
  | 'oscilloscope'
  | 'particles'
  | 'cyber_grid'
  | 'starburst'
  | 'capsules';

export type BackgroundTheme =
  | 'dark_neon'
  | 'pure_black'
  | 'deep_space'
  | 'vibrant_glow'
  | 'matrix'
  | 'custom_image';

export type CenterFrameShape =
  | 'circle'
  | 'spiky_ring'
  | 'keyhole'
  | 'hexagon'
  | 'double_ring';

export type ParticleMode = 'sparks' | 'bokeh_dots' | 'dust' | 'none';

export type SecondaryWaveStyle = 'none' | 'bottom_bars' | 'center_line' | 'mirror_bars';

export type CanvasBlendMode =
  | 'source-over'   // عادي (Normal)
  | 'screen'        // شاشة (Screen)
  | 'overlay'       // تراكب (Overlay)
  | 'difference'    // اختلاف (Difference)
  | 'hard-light'    // ضوء ساطع (Hard Light)
  | 'soft-light'    // ضوء خافت (Soft Light)
  | 'lighten'       // تنوير (Lighten)
  | 'color-dodge';  // توهج لوني (Color Dodge)

export type TitleHideMode = 'sync_with_bar' | 'always_visible' | 'hidden';

export interface Palette {
  id: string;
  name: string;
  colorOne: string;
  colorTwo: string;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  genre: string;
  duration: number; // in seconds
  sourceType: 'procedural' | 'file';
  proceduralId?: string;
  file?: File;
  objectUrl?: string;
}

export interface VisualizerLayer {
  id: string;
  name: string;
  type?: 'image' | 'text';
  imageUrl?: string;
  text?: string;
  textColor?: string;
  x: number;          // Position X percentage (-100 to 100)
  y: number;          // Position Y percentage (-100 to 100)
  scale: number;      // 0.2 to 3.0
  opacity: number;    // 0 to 1.0
  rotation: number;   // 0 to 360 deg
  blendMode: CanvasBlendMode;
  audioReactive: boolean; // Pulses / scales on bass
  visible: boolean;
}

export const BLEND_MODE_OPTIONS: { id: CanvasBlendMode; label: string; desc: string }[] = [
  { id: 'source-over', label: 'عادي (Normal)', desc: 'ظهور قياسي بدون دمج' },
  { id: 'screen', label: 'شاشة (Screen)', desc: 'تفتيح وإضاءة سينمائية شفافة مع الخلفية' },
  { id: 'overlay', label: 'تراكب (Overlay)', desc: 'مزج التباين اللوني والظلال النيونية' },
  { id: 'difference', label: 'اختلاف (Difference)', desc: 'عكس الألوان وتباين إلكتروني مع الطيف' },
  { id: 'hard-light', label: 'ضوء ساطع (Hard Light)', desc: 'إضاءة قوية وتوهج مكثف عالي التباين' },
  { id: 'soft-light', label: 'ضوء خافت (Soft Light)', desc: 'توهج هادئ وناعم للموجات والصور' },
  { id: 'lighten', label: 'تنوير (Lighten)', desc: 'إبقاء الألوان الأكثر إشراقاً وتوهجاً' },
  { id: 'color-dodge', label: 'توهج لوني (Color Dodge)', desc: 'أقصى تشبع لوني وتأثير نيون فاقع' },
];

export interface VisualizerSettings {
  // Shape & Style
  style: VisualizerStyle;

  // Dimensions & Geometry
  barCount: number;         // 16 to 192
  barWidth: number;         // 1 to 14
  barSpacing: number;       // 0 to 12
  roundness: number;        // 0 to 12 px (bar corner radius)
  waveAmplitude: number;    // 0.4 to 2.5 (vertical scale)

  // Dynamic Motion & Audio Response
  glowIntensity: number;    // 0 to 2.0 (neon blur intensity)
  sensitivity: number;      // 0.4 to 2.5 (audio reactivity scale)
  smoothing: number;        // 0.2 to 0.95 (analyser smoothing)
  speed: number;            // 0.5 to 2.5 (animation wave speed)
  bassBoost: number;        // 0.5 to 2.5 (bass amplifier)
  trebleBoost: number;      // 0.5 to 2.5 (treble amplifier)
  showPeakCaps: boolean;    // floating peak points on bars
  beatPulse: boolean;       // canvas background pulse on heavy beats
  fillOpacity: number;      // 0.0 to 1.0 (interior fill translucency)

  // Multi-Layer Waves (موجات فوق بعض)
  enableSecondaryWave: boolean;
  secondaryWaveStyle: SecondaryWaveStyle;
  secondaryWaveHeight: number; // 0.3 to 1.5

  // Avee Player Emblems & Accessories (الأجنحة والتاج وشكل الإطار)
  showAngelWings: boolean;      // أجنحة النيون المشعة
  wingsSpread: number;          // 0.5 to 1.8
  showRoyalCrown: boolean;      // التاج الملكي المشع أعلى الدائرة
  crownScale: number;           // 0.6 to 1.5
  centerFrameShape: CenterFrameShape;
  showInnerEqualizer: boolean;  // مدرج ترددات مصغر داخل الشعار الدائري

  // Particles & Visual FX (البوكيه والشرارات)
  particleMode: ParticleMode;
  particleSpeed: number;        // 0.5 to 2.5
  particleCount: number;        // 20 to 120

  // Canvas & Background
  backgroundTheme: BackgroundTheme;
  showGrid: boolean;
  gridSpacing: number;          // 15 to 45
  showCenterGlow: boolean;

  // Custom Background Wallpaper Controls (تكبير، تصغير، إزاحة، حركة الباس)
  backgroundImageUrl: string | null;
  backgroundBlur: number;         // 0 to 20 px
  backgroundOpacity: number;      // 0.1 to 1.0
  bgScale: number;                // 0.5 to 2.5 (Zoom)
  bgOffsetX: number;              // -100 to 100 percentage (Pan X)
  bgOffsetY: number;              // -100 to 100 percentage (Pan Y)
  bgAudioMotion: boolean;         // Move / pulse background with bass audio
  bgMotionIntensity: number;      // 0.5 to 2.0

  // Center Avatar Image
  waveCenterImageUrl: string | null; // صورة في قلب الموجات (شعار / قرص الفينيل / غلاف)
  waveCenterImageSpin: boolean;   // دوران الصورة مع الموسيقى
  waveCenterImageSize: number;    // 40 to 160 px
  waveCenterImageBorder: boolean; // إطار نيون مشع حول الصورة

  // Blend Modes for Components (أوضاع المزج: شاشة، تراكب، اختلاف، ضوء ساطع، إلخ)
  bgBlendMode: CanvasBlendMode;
  waveBlendMode: CanvasBlendMode;
  centerAvatarBlendMode: CanvasBlendMode;
  textBlendMode: CanvasBlendMode;

  // Custom Unlimited Layers (نظام الطبقات اللانهائي)
  layers: VisualizerLayer[];

  // Texts & Typography (نصوص وأسماء الأغاني وعلامة مائية)
  showTrackTitle: boolean;
  showTrackArtist: boolean;
  titleHideMode: TitleHideMode;   // 'sync_with_bar' | 'always_visible' | 'hidden'
  customWatermarkText: string;    // نص مخصص مثل EGO_MUSIC7
  showWatermark: boolean;
  textPosition: 'top' | 'center' | 'bottom';
  textGlow: boolean;
  textColor: string;
  textSize: 'small' | 'medium' | 'large';

  // Lock Controls
  lockControlsVisible: boolean;   // تثبيت الأزرار دائماً ومنع اختفائها

  // Colors
  colorMode: 'palette' | 'custom';
  customColorOne: string;
  customColorTwo: string;

  // Audio Playback
  fadeEnabled: boolean;
  fadeDuration: number;     // In seconds (e.g. 0.4s)
  playbackRate: number;     // 0.5 to 2.0
}

export const DEFAULT_SETTINGS: VisualizerSettings = {
  style: 'radial',
  barCount: 64,
  barWidth: 4,
  barSpacing: 2,
  roundness: 4,
  waveAmplitude: 1.0,
  glowIntensity: 1.2,
  sensitivity: 1.1,
  smoothing: 0.8,
  speed: 1.0,
  bassBoost: 1.4,
  trebleBoost: 1.0,
  showPeakCaps: true,
  beatPulse: true,
  fillOpacity: 0.35,

  // Multi-layer
  enableSecondaryWave: true,
  secondaryWaveStyle: 'bottom_bars',
  secondaryWaveHeight: 0.8,

  // Emblems
  showAngelWings: false,
  wingsSpread: 1.0,
  showRoyalCrown: false,
  crownScale: 1.0,
  centerFrameShape: 'circle',
  showInnerEqualizer: true,

  // Particles
  particleMode: 'sparks',
  particleSpeed: 1.0,
  particleCount: 50,

  // Background
  backgroundTheme: 'dark_neon',
  showGrid: true,
  gridSpacing: 25,
  showCenterGlow: true,

  // Background Image & Pan/Zoom/Motion
  backgroundImageUrl: '/src/assets/images/avee_soundwaves_bg_1792096100191.jpg',
  backgroundBlur: 0,
  backgroundOpacity: 0.88,
  bgScale: 1.0,
  bgOffsetX: 0,
  bgOffsetY: 0,
  bgAudioMotion: true,
  bgMotionIntensity: 1.0,

  // Center Avatar
  waveCenterImageUrl: null,
  waveCenterImageSpin: true,
  waveCenterImageSize: 95,
  waveCenterImageBorder: true,

  // Blend Modes
  bgBlendMode: 'source-over',
  waveBlendMode: 'source-over',
  centerAvatarBlendMode: 'source-over',
  textBlendMode: 'source-over',

  // Layers
  layers: [],

  // Texts
  showTrackTitle: true,
  showTrackArtist: true,
  titleHideMode: 'sync_with_bar',
  customWatermarkText: 'EGO_MUSIC',
  showWatermark: true,
  textPosition: 'top',
  textGlow: true,
  textColor: '#FFFFFF',
  textSize: 'medium',

  // Controls lock
  lockControlsVisible: false,

  // Colors
  colorMode: 'palette',
  customColorOne: '#00E5FF',
  customColorTwo: '#9C27B0',
  fadeEnabled: true,
  fadeDuration: 0.4,
  playbackRate: 1.0,
};

export const COLOR_PALETTES: Palette[] = [
  {
    id: 'cyber',
    name: 'نيون سايبر',
    colorOne: '#00E5FF',
    colorTwo: '#9C27B0',
  },
  {
    id: 'fire',
    name: 'شروق ناري',
    colorOne: '#FF1744',
    colorTwo: '#FF9100',
  },
  {
    id: 'emerald',
    name: 'واحة المستقبل',
    colorOne: '#76FF03',
    colorTwo: '#00BFA5',
  },
  {
    id: 'sunset',
    name: 'غروب استوائي',
    colorOne: '#FFD740',
    colorTwo: '#FF4081',
  },
  {
    id: 'royal_purple',
    name: 'أرجواني ملكي',
    colorOne: '#B388FF',
    colorTwo: '#7C4DFF',
  },
  {
    id: 'electric_violet',
    name: 'بنفسجي كهربائي',
    colorOne: '#D500F9',
    colorTwo: '#00E5FF',
  },
  {
    id: 'toxic_lime',
    name: 'لايم متوهج',
    colorOne: '#AEEA00',
    colorTwo: '#00E676',
  },
  {
    id: 'synthwave',
    name: 'سينث ويف 80s',
    colorOne: '#FF007F',
    colorTwo: '#00F0FF',
  },
  {
    id: 'gold_luxury',
    name: 'ذهب نقي',
    colorOne: '#FFD700',
    colorTwo: '#FF6F00',
  },
  {
    id: 'silver',
    name: 'أبيض ماسي',
    colorOne: '#FFFFFF',
    colorTwo: '#607D8B',
  },
];

export const PRESET_WALLPAPERS = [
  {
    id: 'vocal_frequencies_8k',
    name: 'طيف الترددات الصوتية 3D (8K)',
    desc: '7 طبقات صوتية سائلة من السوبرانو للباس بستوديو مستقبلي نيون',
    url: '/src/assets/images/avee_soundwaves_bg_1792096100191.jpg',
  },
];

