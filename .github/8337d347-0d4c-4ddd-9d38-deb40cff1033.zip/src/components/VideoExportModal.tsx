import React, { useState, useRef, useEffect } from 'react';
import { Palette, Track } from '../types';
import { audioEngine } from '../utils/audioEngine';
import {
  X,
  Video,
  Download,
  Camera,
  Play,
  Square,
  Sparkles,
  Check,
  AlertCircle,
  Clock,
  Film,
} from 'lucide-react';

interface VideoExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  canvas: HTMLCanvasElement | null;
  currentTrack: Track;
  currentPalette: Palette;
  isPlaying: boolean;
  onStartPlayback: () => void;
}

export const VideoExportModal: React.FC<VideoExportModalProps> = ({
  isOpen,
  onClose,
  canvas,
  currentTrack,
  currentPalette,
  isPlaying,
  onStartPlayback,
}) => {
  const [selectedDuration, setSelectedDuration] = useState<number>(15); // 15s default for reels/stories
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordedSeconds, setRecordedSeconds] = useState<number>(0);
  const [videoBlobUrl, setVideoBlobUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [snapshotSuccess, setSnapshotSuccess] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (videoBlobUrl) URL.revokeObjectURL(videoBlobUrl);
    };
  }, [videoBlobUrl]);

  if (!isOpen) return null;

  // Take High-Res Screenshot
  const handleTakeSnapshot = () => {
    if (!canvas) {
      setErrorMessage('لوحة المؤثرات غير جاهزة');
      return;
    }
    try {
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `Avee_${currentTrack?.title || 'Visualizer'}_${Date.now()}.png`;
      a.click();
      setSnapshotSuccess(true);
      setTimeout(() => setSnapshotSuccess(false), 2500);
    } catch (err) {
      console.error('Snapshot failed:', err);
      setErrorMessage('فشل التقاط الصورة من الشاشة');
    }
  };

  // Start Video Recording with Synchronized Audio
  const handleStartRecording = () => {
    setErrorMessage(null);
    if (!canvas) {
      setErrorMessage('لوحة المؤثرات غير متوفرة للتسجيل');
      return;
    }

    try {
      // 1. Capture Canvas Video Stream at 30/60 fps
      const canvasStream = canvas.captureStream(30);

      // 2. Capture synchronized audio stream from AudioEngine
      const audioStream = audioEngine.getAudioStream();
      const combinedTracks: MediaStreamTrack[] = [...canvasStream.getVideoTracks()];

      if (audioStream && audioStream.getAudioTracks().length > 0) {
        combinedTracks.push(...audioStream.getAudioTracks());
      }

      const combinedStream = new MediaStream(combinedTracks);

      // Choose supported mimeType
      let mimeType = 'video/webm;codecs=vp9,opus';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm;codecs=vp8,opus';
      }
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm';
      }
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/mp4';
      }

      const recorder = new MediaRecorder(combinedStream, {
        mimeType: MediaRecorder.isTypeSupported(mimeType) ? mimeType : undefined,
        videoBitsPerSecond: 4500000, // 4.5 Mbps high quality
      });

      recordedChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        setIsProcessing(true);
        const finalBlob = new Blob(recordedChunksRef.current, {
          type: recorder.mimeType || 'video/webm',
        });
        const url = URL.createObjectURL(finalBlob);
        setVideoBlobUrl(url);
        setIsProcessing(false);
        setIsRecording(false);
      };

      recorder.start(250);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordedSeconds(0);
      setVideoBlobUrl(null);

      // If not playing, start audio playback
      if (!isPlaying) {
        onStartPlayback();
      }

      // Interval timer & auto-stop
      let elapsed = 0;
      timerIntervalRef.current = window.setInterval(() => {
        elapsed += 1;
        setRecordedSeconds(elapsed);

        if (selectedDuration > 0 && elapsed >= selectedDuration) {
          handleStopRecording();
        }
      }, 1000);
    } catch (err: unknown) {
      console.error('Failed to start recording:', err);
      const msg = err instanceof Error ? err.message : String(err);
      setErrorMessage(`تعذر بدء التسجيل في هذا المتصفح: ${msg}`);
      setIsRecording(false);
    }
  };

  // Stop Recording
  const handleStopRecording = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
  };

  // Download Recorded Video
  const handleDownloadVideo = () => {
    if (!videoBlobUrl) return;
    const a = document.createElement('a');
    a.href = videoBlobUrl;
    a.download = `Avee_Video_${currentTrack?.title || 'Track'}_${Date.now()}.webm`;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md transition-opacity">
      <div
        className="w-full max-w-lg bg-[#121520] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#151926]">
          <div className="flex items-center gap-3">
            <div
              className="p-2.5 rounded-2xl shadow-sm"
              style={{
                backgroundColor: `${currentPalette.colorOne}20`,
                color: currentPalette.colorOne,
              }}
            >
              <Film className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">تصدير فيديو وموجات Avee</h2>
              <p className="text-xs text-white/50">تسجيل وتصدير فيديو بجودة عالية مع الموسيقى والموجات</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (isRecording) handleStopRecording();
              onClose();
            }}
            className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {/* Quick Snapshot Card */}
          <div className="p-4 bg-[#151926] rounded-2xl border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-white/5 text-cyan-400">
                <Camera className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-bold text-white block">لقطة شاشة فورية عالية الدقة</span>
                <span className="text-xs text-white/40 block">حفظ شاشة العرض كصورة خلفية PNG بدقة كاملة</span>
              </div>
            </div>
            <button
              onClick={handleTakeSnapshot}
              className="px-4 py-2.5 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/15 text-white transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              {snapshotSuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">تم الحفظ!</span>
                </>
              ) : (
                <>
                  <Camera className="w-4 h-4" />
                  <span>التقاط صورة</span>
                </>
              )}
            </button>
          </div>

          {/* Video Export Duration Selector */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-white/80 block flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>مدة مقطع الفيديو المراد تصديره:</span>
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: '10 ثوانٍ', val: 10 },
                { label: '15 ثانية (Story)', val: 15 },
                { label: '30 ثانية (Reels)', val: 30 },
                { label: 'تسجيل يدوي', val: 0 },
              ].map((dur) => {
                const isSelected = selectedDuration === dur.val;
                return (
                  <button
                    key={dur.val}
                    disabled={isRecording}
                    onClick={() => setSelectedDuration(dur.val)}
                    className={`p-2.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-transparent text-black shadow-lg'
                        : 'border-white/10 bg-[#151926] text-white/70 hover:bg-white/5'
                    }`}
                    style={
                      isSelected
                        ? {
                            background: `linear-gradient(135deg, ${currentPalette.colorOne}, ${currentPalette.colorTwo})`,
                          }
                        : {}
                    }
                  >
                    {dur.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Recording Status / Live View */}
          <div className="p-5 bg-[#0D0F17] rounded-2xl border border-white/5 flex flex-col items-center justify-center text-center space-y-3">
            {isRecording ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-xs font-bold animate-pulse">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                  <span>جاري تسجيل الفيديو مع الصوت... ({recordedSeconds} ثانية)</span>
                </div>
                {selectedDuration > 0 && (
                  <div className="w-48 h-2 bg-white/10 rounded-full overflow-hidden mx-auto">
                    <div
                      className="h-full bg-red-500 transition-all duration-300"
                      style={{ width: `${(recordedSeconds / selectedDuration) * 100}%` }}
                    />
                  </div>
                )}
                <button
                  onClick={handleStopRecording}
                  className="px-6 py-2.5 bg-red-500 hover:bg-red-600 text-white font-bold text-xs rounded-xl shadow-lg flex items-center gap-2 mx-auto cursor-pointer"
                >
                  <Square className="w-4 h-4 fill-white" />
                  <span>إيقاف وإنهاء التسجيل</span>
                </button>
              </div>
            ) : videoBlobUrl ? (
              <div className="w-full space-y-3">
                <div className="flex items-center justify-center gap-2 text-xs font-bold text-emerald-400">
                  <Check className="w-4 h-4" />
                  <span>تم تجهيز الفيديو وتوليده بنجاح!</span>
                </div>
                {/* Video Player Preview */}
                <video
                  src={videoBlobUrl}
                  controls
                  playsInline
                  className="w-full max-h-48 rounded-xl bg-black border border-white/10"
                />
                <button
                  onClick={handleDownloadVideo}
                  className="w-full py-3 rounded-xl font-bold text-black text-sm transition-all transform active:scale-[0.98] shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                  style={{
                    background: `linear-gradient(135deg, ${currentPalette.colorOne}, ${currentPalette.colorTwo})`,
                    boxShadow: `0 4px 20px ${currentPalette.colorOne}40`,
                  }}
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل الفيديو على جهازك</span>
                </button>
              </div>
            ) : isProcessing ? (
              <div className="py-4 flex flex-col items-center gap-2 text-white/70">
                <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                <span className="text-xs">جاري تجميع الفيديو ومعالجة الصوت...</span>
              </div>
            ) : (
              <div className="space-y-3">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto shadow-lg"
                  style={{
                    backgroundColor: `${currentPalette.colorOne}18`,
                    color: currentPalette.colorOne,
                  }}
                >
                  <Video className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">جاهز لبدء تصدير الفيديو</h3>
                  <p className="text-xs text-white/40 mt-1 max-w-xs mx-auto">
                    سيقوم بتسجيل ما يظهر على الشاشة (الموجات، الصور، والنصوص) مع الموسيقى مباشرة
                  </p>
                </div>
                <button
                  onClick={handleStartRecording}
                  className="px-6 py-3 rounded-xl font-bold text-black text-xs transition-all transform active:scale-95 shadow-lg flex items-center gap-2 mx-auto cursor-pointer"
                  style={{
                    background: `linear-gradient(135deg, ${currentPalette.colorOne}, ${currentPalette.colorTwo})`,
                    boxShadow: `0 4px 16px ${currentPalette.colorOne}35`,
                  }}
                >
                  <Play className="w-4 h-4 fill-black text-black" />
                  <span>بدء تسجيل الفيديو الآن</span>
                </button>
              </div>
            )}
          </div>

          {errorMessage && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#151926] flex justify-end">
          <button
            onClick={() => {
              if (isRecording) handleStopRecording();
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white/60 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
