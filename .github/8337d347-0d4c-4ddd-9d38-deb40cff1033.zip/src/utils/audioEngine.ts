import { Track } from '../types';
import { DEMO_TRACKS, bufferToWaveBlob } from './proceduralAudio';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private audioEl: HTMLAudioElement | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private frequencyDataArray: Uint8Array<ArrayBuffer> | null = null;
  private blobUrlCache: Map<string, string> = new Map();

  private isInitialized = false;
  private targetVolume = 0.85;
  private fadeDuration = 0.4; // 400ms fade transition
  private isFadeEnabled = true;
  private playbackRate = 1.0;

  public init() {
    if (this.isInitialized && this.ctx && this.audioEl) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return;
    }

    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioContextClass();

    this.audioEl = new Audio();
    this.audioEl.crossOrigin = 'anonymous';
    this.audioEl.preload = 'auto';
    this.audioEl.playbackRate = this.playbackRate;

    this.analyserNode = this.ctx.createAnalyser();
    // High-precision 2048 FFT (1024 frequency bins) for ultra-accurate sub-bass & treble response
    this.analyserNode.fftSize = 2048;
    this.analyserNode.minDecibels = -90;
    this.analyserNode.maxDecibels = -10;
    this.analyserNode.smoothingTimeConstant = 0.78;
    this.frequencyDataArray = new Uint8Array(this.analyserNode.frequencyBinCount);

    this.gainNode = this.ctx.createGain();
    this.gainNode.gain.value = this.targetVolume;

    try {
      this.sourceNode = this.ctx.createMediaElementSource(this.audioEl);
      this.sourceNode.connect(this.analyserNode);
      this.analyserNode.connect(this.gainNode);
      this.gainNode.connect(this.ctx.destination);
    } catch (e) {
      console.warn('MediaElementSource error:', e);
    }

    this.isInitialized = true;
  }

  private mediaStreamDest: MediaStreamAudioDestinationNode | null = null;

  public getAudioStream(): MediaStream | null {
    this.init();
    if (!this.ctx || !this.gainNode) return null;
    if (!this.mediaStreamDest) {
      try {
        this.mediaStreamDest = this.ctx.createMediaStreamDestination();
        this.gainNode.connect(this.mediaStreamDest);
      } catch (err) {
        console.warn('Failed to create media stream destination:', err);
      }
    }
    return this.mediaStreamDest ? this.mediaStreamDest.stream : null;
  }

  public getAudioElement(): HTMLAudioElement | null {
    return this.audioEl;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public getFrequencyData(): Uint8Array<ArrayBuffer> | null {
    if (!this.analyserNode || !this.frequencyDataArray) return null;
    this.analyserNode.getByteFrequencyData(this.frequencyDataArray);
    return this.frequencyDataArray;
  }

  public setSmoothing(smoothing: number) {
    if (this.analyserNode) {
      this.analyserNode.smoothingTimeConstant = Math.max(0.0, Math.min(0.98, smoothing));
    }
  }

  public setPlaybackRate(rate: number) {
    this.playbackRate = Math.max(0.25, Math.min(3.0, rate));
    if (this.audioEl) {
      this.audioEl.playbackRate = this.playbackRate;
    }
  }

  public getPlaybackRate(): number {
    return this.playbackRate;
  }

  public setFftSize(fftSize: number) {
    if (this.analyserNode && (fftSize === 128 || fftSize === 256 || fftSize === 512 || fftSize === 1024)) {
      this.analyserNode.fftSize = fftSize;
      this.frequencyDataArray = new Uint8Array(this.analyserNode.frequencyBinCount);
    }
  }

  public setFadeConfig(enabled: boolean, durationSec: number) {
    this.isFadeEnabled = enabled;
    this.fadeDuration = Math.max(0.1, Math.min(3.0, durationSec));
  }

  public async loadTrack(track: Track): Promise<string> {
    this.init();
    if (!this.audioEl || !this.ctx) throw new Error('Audio engine failed to initialize');

    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }

    let urlToPlay = '';

    if (track.sourceType === 'file' && track.objectUrl) {
      urlToPlay = track.objectUrl;
    } else if (track.sourceType === 'procedural' && track.proceduralId) {
      // Check cache first
      if (this.blobUrlCache.has(track.proceduralId)) {
        urlToPlay = this.blobUrlCache.get(track.proceduralId)!;
      } else {
        const demo = DEMO_TRACKS.find((d) => d.id === track.proceduralId);
        if (demo) {
          const buffer = demo.generator(this.ctx, demo.duration);
          const blob = bufferToWaveBlob(buffer);
          urlToPlay = URL.createObjectURL(blob);
          this.blobUrlCache.set(track.proceduralId, urlToPlay);
        }
      }
    }

    if (urlToPlay) {
      this.audioEl.src = urlToPlay;
      this.audioEl.playbackRate = this.playbackRate;
      this.audioEl.load();
    }

    return urlToPlay;
  }

  /**
   * Fade in smoothly to target volume
   */
  public fadeIn(duration = this.fadeDuration): void {
    if (!this.gainNode || !this.ctx) return;
    const now = this.ctx.currentTime;
    this.gainNode.gain.cancelScheduledValues(now);
    this.gainNode.gain.setValueAtTime(0.0001, now);
    this.gainNode.gain.linearRampToValueAtTime(this.targetVolume, now + duration);
  }

  /**
   * Fade out smoothly to silence and return promise
   */
  public fadeOut(duration = this.fadeDuration): Promise<void> {
    return new Promise((resolve) => {
      if (!this.gainNode || !this.ctx) {
        resolve();
        return;
      }
      const now = this.ctx.currentTime;
      const currentGain = Math.max(0.0001, this.gainNode.gain.value);
      this.gainNode.gain.cancelScheduledValues(now);
      this.gainNode.gain.setValueAtTime(currentGain, now);
      this.gainNode.gain.linearRampToValueAtTime(0.0001, now + duration);

      setTimeout(() => {
        resolve();
      }, Math.max(50, duration * 1000));
    });
  }

  public async play(fade = this.isFadeEnabled, customDuration?: number): Promise<void> {
    this.init();
    if (this.ctx?.state === 'suspended') {
      await this.ctx.resume();
    }

    if (this.audioEl) {
      this.audioEl.playbackRate = this.playbackRate;
      if (fade && this.gainNode && this.ctx) {
        const now = this.ctx.currentTime;
        this.gainNode.gain.cancelScheduledValues(now);
        this.gainNode.gain.setValueAtTime(0.0001, now);
        await this.audioEl.play();
        const duration = customDuration ?? this.fadeDuration;
        this.gainNode.gain.linearRampToValueAtTime(this.targetVolume, now + duration);
      } else {
        if (this.gainNode && this.ctx) {
          const now = this.ctx.currentTime;
          this.gainNode.gain.cancelScheduledValues(now);
          this.gainNode.gain.setValueAtTime(this.targetVolume, now);
        }
        await this.audioEl.play();
      }
    }
  }

  public async pause(fade = this.isFadeEnabled, customDuration?: number): Promise<void> {
    if (!this.audioEl) return;

    if (fade && !this.audioEl.paused && this.gainNode && this.ctx) {
      const duration = customDuration ?? this.fadeDuration;
      await this.fadeOut(duration);
      if (this.audioEl) {
        this.audioEl.pause();
      }
      if (this.gainNode && this.ctx) {
        this.gainNode.gain.cancelScheduledValues(this.ctx.currentTime);
        this.gainNode.gain.setValueAtTime(this.targetVolume, this.ctx.currentTime);
      }
    } else {
      this.audioEl.pause();
    }
  }

  public async transitionToTrack(
    track: Track,
    autoPlay = true,
    fade = this.isFadeEnabled,
    customDuration?: number
  ): Promise<void> {
    this.init();
    const duration = customDuration ?? this.fadeDuration;

    if (this.audioEl && !this.audioEl.paused && fade) {
      await this.fadeOut(duration);
    }

    await this.loadTrack(track);

    if (autoPlay) {
      await this.play(fade, duration);
    }
  }

  public seek(seconds: number): void {
    if (this.audioEl) {
      this.audioEl.currentTime = Math.max(0, Math.min(seconds, this.audioEl.duration || 0));
    }
  }

  public skip(deltaSeconds: number): void {
    if (this.audioEl) {
      const next = (this.audioEl.currentTime || 0) + deltaSeconds;
      const duration = this.audioEl.duration || 0;
      this.audioEl.currentTime = Math.max(0, duration > 0 ? Math.min(next, duration) : next);
    }
  }

  public setVolume(vol: number): void {
    const clamped = Math.max(0, Math.min(1, vol));
    this.targetVolume = clamped;
    if (this.gainNode && this.ctx) {
      this.gainNode.gain.cancelScheduledValues(this.ctx.currentTime);
      this.gainNode.gain.setValueAtTime(clamped, this.ctx.currentTime);
    }
  }

  public setLoop(loop: boolean): void {
    if (this.audioEl) {
      this.audioEl.loop = loop;
    }
  }

  public cleanup() {
    if (this.blobUrlCache.size > 0) {
      this.blobUrlCache.forEach((url) => URL.revokeObjectURL(url));
      this.blobUrlCache.clear();
    }
  }
}

export const audioEngine = new AudioEngine();
