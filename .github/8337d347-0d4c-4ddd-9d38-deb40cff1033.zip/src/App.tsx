import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Track,
  VisualizerSettings,
  VisualizerStyle,
  TitleHideMode,
  COLOR_PALETTES,
  Palette,
  DEFAULT_SETTINGS,
} from './types';
import { DEMO_TRACKS } from './utils/proceduralAudio';
import { audioEngine } from './utils/audioEngine';
import { VisualizerCanvas } from './components/VisualizerCanvas';
import { SettingsModal } from './components/SettingsModal';
import { PlaylistModal } from './components/PlaylistModal';
import { VideoExportModal } from './components/VideoExportModal';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Shuffle,
  Repeat1,
  Repeat,
  Palette as PaletteIcon,
  FolderOpen,
  Sliders,
  ListMusic,
  Volume2,
  VolumeX,
  AudioWaveform,
  Upload,
  Waves,
  Film,
  Eye,
  EyeOff,
  Type,
  Lock,
  Unlock,
  Music,
} from 'lucide-react';

const STYLE_LABELS: Record<VisualizerStyle, string> = {
  radial: 'حلقة Avee الدائرية',
  mirror: 'متناظر نيون',
  bars: 'مدرج ترددات',
  wave: 'موجة متصلة',
  spiral: 'دوامة كونية',
  oscilloscope: 'راسم الذبذبات',
  particles: 'شرارات وجسيمات',
  cyber_grid: 'طبقات 3D',
  starburst: 'نجمة مشعة',
  capsules: 'كبسولات عائمة',
};

const STYLES_ORDER: VisualizerStyle[] = [
  'radial',
  'mirror',
  'bars',
  'wave',
  'spiral',
  'oscilloscope',
  'particles',
  'cyber_grid',
  'starburst',
  'capsules',
];

export default function App() {
  const [playlist, setPlaylist] = useState<Track[]>(() =>
    DEMO_TRACKS.map((demo) => ({
      id: demo.id,
      title: demo.title,
      artist: demo.artist,
      genre: demo.genre,
      duration: demo.duration,
      sourceType: 'procedural',
      proceduralId: demo.id,
    }))
  );

  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const currentTrack = playlist[currentTrackIndex] || playlist[0];

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<'off' | 'one' | 'all'>('all');

  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Palettes (default: cyan #00E5FF and purple #9C27B0)
  const [paletteIndex, setPaletteIndex] = useState<number>(0);
  const currentPalette = COLOR_PALETTES[paletteIndex] || COLOR_PALETTES[0];

  // Visualizer settings
  const [settings, setSettings] = useState<VisualizerSettings>(DEFAULT_SETTINGS);

  // Canvas element ref for video export / snapshots
  const [canvasElement, setCanvasElement] = useState<HTMLCanvasElement | null>(null);

  // Auto-hide controls state
  const [isControlsVisible, setIsControlsVisible] = useState<boolean>(true);
  const inactivityTimeoutRef = useRef<number | null>(null);

  // Active colors computed from palette or custom color picker
  const activeColorOne =
    settings.colorMode === 'custom' ? settings.customColorOne : currentPalette.colorOne;
  const activeColorTwo =
    settings.colorMode === 'custom' ? settings.customColorTwo : currentPalette.colorTwo;

  // Sync fade configuration with AudioEngine
  useEffect(() => {
    audioEngine.setFadeConfig(settings.fadeEnabled, settings.fadeDuration);
  }, [settings.fadeEnabled, settings.fadeDuration]);

  // Sync playback rate with AudioEngine
  useEffect(() => {
    audioEngine.setPlaybackRate(settings.playbackRate);
  }, [settings.playbackRate]);

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isPlaylistOpen, setIsPlaylistOpen] = useState<boolean>(false);
  const [isVideoExportOpen, setIsVideoExportOpen] = useState<boolean>(false);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Format mm:ss
  const formatDuration = (totalSeconds: number): string => {
    if (!totalSeconds || isNaN(totalSeconds) || totalSeconds < 0) return '00:00';
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Auto-hide timer logic (Hides controls after 3.8s when playing unless locked)
  const resetInactivityTimer = useCallback(() => {
    setIsControlsVisible(true);
    if (inactivityTimeoutRef.current) {
      clearTimeout(inactivityTimeoutRef.current);
      inactivityTimeoutRef.current = null;
    }
    if (isPlaying && !settings.lockControlsVisible) {
      inactivityTimeoutRef.current = window.setTimeout(() => {
        setIsControlsVisible(false);
      }, 3800);
    }
  }, [isPlaying, settings.lockControlsVisible]);

  useEffect(() => {
    if (!isPlaying || settings.lockControlsVisible) {
      setIsControlsVisible(true);
      if (inactivityTimeoutRef.current) {
        clearTimeout(inactivityTimeoutRef.current);
        inactivityTimeoutRef.current = null;
      }
    } else {
      resetInactivityTimer();
    }
    return () => {
      if (inactivityTimeoutRef.current) {
        clearTimeout(inactivityTimeoutRef.current);
      }
    };
  }, [isPlaying, settings.lockControlsVisible, resetInactivityTimer]);

  // Toggle controls on screen tap (touching screen hides and shows top/bottom bars)
  const toggleControls = useCallback(() => {
    setIsControlsVisible((prev) => {
      const next = !prev;
      if (next) {
        if (isPlaying && !settings.lockControlsVisible) {
          if (inactivityTimeoutRef.current) clearTimeout(inactivityTimeoutRef.current);
          inactivityTimeoutRef.current = window.setTimeout(() => {
            setIsControlsVisible(false);
          }, 4500);
        }
      } else {
        if (inactivityTimeoutRef.current) {
          clearTimeout(inactivityTimeoutRef.current);
          inactivityTimeoutRef.current = null;
        }
      }
      return next;
    });
  }, [isPlaying, settings.lockControlsVisible]);

  // Global screen touch / click listener: tapping the background or visualizer toggles controls
  useEffect(() => {
    const handleGlobalTap = (e: MouseEvent | TouchEvent) => {
      const target = e.target as HTMLElement | null;
      // Do not toggle if tapping interactive buttons, inputs, modals, or ranges
      if (
        !target ||
        target.closest('button') ||
        target.closest('input') ||
        target.closest('[role="dialog"]') ||
        target.closest('.modal-container')
      ) {
        resetInactivityTimer();
        return;
      }

      // If user tapped outside interactive elements (on canvas / screen background), toggle controls!
      toggleControls();
    };

    window.addEventListener('click', handleGlobalTap);
    return () => {
      window.removeEventListener('click', handleGlobalTap);
    };
  }, [toggleControls, resetInactivityTimer]);

  // Switch to next palette
  const cyclePalette = () => {
    if (settings.colorMode === 'custom') {
      setSettings((prev) => ({ ...prev, colorMode: 'palette' }));
    } else {
      setPaletteIndex((prev) => (prev + 1) % COLOR_PALETTES.length);
    }
  };

  // Cycle to next wave style quickly
  const cycleWaveStyle = () => {
    setSettings((prev) => {
      const currentIndex = STYLES_ORDER.indexOf(prev.style);
      const nextIndex = (currentIndex + 1) % STYLES_ORDER.length;
      return { ...prev, style: STYLES_ORDER[nextIndex] };
    });
  };

  // Load and play track with smooth crossfade
  const playTrack = useCallback(
    async (track: Track, autoPlay = true) => {
      try {
        await audioEngine.transitionToTrack(
          track,
          autoPlay,
          settings.fadeEnabled,
          settings.fadeDuration
        );
        if (autoPlay) {
          setIsPlaying(true);
        }
      } catch (err) {
        console.error('Error loading track:', err);
      }
    },
    [settings.fadeEnabled, settings.fadeDuration]
  );

  // Listen to audio element timeupdate and state
  useEffect(() => {
    const audioEl = audioEngine.getAudioElement();
    if (!audioEl) {
      audioEngine.init();
    }
    const el = audioEngine.getAudioElement();
    if (!el) return;

    const handleTimeUpdate = () => {
      setCurrentTime(el.currentTime || 0);
    };

    const handleLoadedMetadata = () => {
      setDuration(el.duration || currentTrack?.duration || 0);
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    const handleEnded = () => {
      if (repeatMode === 'one') {
        el.currentTime = 0;
        audioEngine.play(settings.fadeEnabled, settings.fadeDuration).catch(() => {});
      } else {
        handleSkipTrack(1);
      }
    };

    el.addEventListener('timeupdate', handleTimeUpdate);
    el.addEventListener('loadedmetadata', handleLoadedMetadata);
    el.addEventListener('play', handlePlay);
    el.addEventListener('pause', handlePause);
    el.addEventListener('ended', handleEnded);

    return () => {
      el.removeEventListener('timeupdate', handleTimeUpdate);
      el.removeEventListener('loadedmetadata', handleLoadedMetadata);
      el.removeEventListener('play', handlePlay);
      el.removeEventListener('pause', handlePause);
      el.removeEventListener('ended', handleEnded);
    };
  }, [currentTrack, repeatMode, settings.fadeEnabled, settings.fadeDuration]);

  // Handle Play / Pause Toggle with smooth fade
  const togglePlay = async () => {
    resetInactivityTimer();
    const el = audioEngine.getAudioElement();
    if (!el || !el.src) {
      if (currentTrack) {
        await playTrack(currentTrack, true);
      }
      return;
    }

    if (isPlaying) {
      setIsPlaying(false);
      await audioEngine.pause(settings.fadeEnabled, settings.fadeDuration);
    } else {
      setIsPlaying(true);
      await audioEngine.play(settings.fadeEnabled, settings.fadeDuration);
    }
  };

  // Skip 10 seconds backwards
  const skipBackward10 = () => {
    resetInactivityTimer();
    audioEngine.skip(-10);
  };

  // Skip 10 seconds forwards
  const skipForward10 = () => {
    resetInactivityTimer();
    audioEngine.skip(10);
  };

  // Skip track (next or prev)
  const handleSkipTrack = useCallback(
    async (direction: 1 | -1) => {
      resetInactivityTimer();
      if (playlist.length <= 1) return;

      let nextIndex = currentTrackIndex;
      if (isShuffle) {
        let rand = Math.floor(Math.random() * playlist.length);
        if (rand === currentTrackIndex) {
          rand = (rand + 1) % playlist.length;
        }
        nextIndex = rand;
      } else {
        nextIndex = (currentTrackIndex + direction + playlist.length) % playlist.length;
      }

      setCurrentTrackIndex(nextIndex);
      const nextTrack = playlist[nextIndex];
      if (nextTrack) {
        await playTrack(nextTrack, true);
      }
    },
    [currentTrackIndex, isShuffle, playlist, playTrack, resetInactivityTimer]
  );

  // Toggle Repeat Mode
  const cycleRepeat = () => {
    resetInactivityTimer();
    setRepeatMode((prev) => {
      if (prev === 'off') {
        audioEngine.setLoop(true);
        return 'one';
      }
      if (prev === 'one') {
        audioEngine.setLoop(false);
        return 'all';
      }
      audioEngine.setLoop(false);
      return 'off';
    });
  };

  // Seek handler
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    resetInactivityTimer();
    const newTime = Number(e.target.value);
    setCurrentTime(newTime);
    audioEngine.seek(newTime);
  };

  // Volume change
  const handleVolumeChange = (newVol: number) => {
    resetInactivityTimer();
    setVolume(newVol);
    if (newVol > 0 && isMuted) {
      setIsMuted(false);
    }
    audioEngine.setVolume(isMuted ? 0 : newVol);
  };

  // Toggle Mute
  const toggleMute = () => {
    resetInactivityTimer();
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    audioEngine.setVolume(newMuted ? 0 : volume);
  };

  // Load custom audio files
  const handleAddFiles = (files: FileList | File[]) => {
    const newTracks: Track[] = [];

    Array.from(files).forEach((file) => {
      if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|aac|flac|m4a)$/i)) {
        return;
      }

      const cleanTitle = file.name.replace(/\.[^/.]+$/, '');
      const objectUrl = URL.createObjectURL(file);

      const track: Track = {
        id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        title: cleanTitle,
        artist: 'ملف محلي',
        genre: 'صوت مخصص',
        duration: 0,
        sourceType: 'file',
        file: file,
        objectUrl: objectUrl,
      };

      newTracks.push(track);
    });

    if (newTracks.length > 0) {
      setPlaylist((prev) => [...newTracks, ...prev]);
      setCurrentTrackIndex(0);
      playTrack(newTracks[0], true);
      setIsPlaylistOpen(false);
    }
  };

  // File Picker Trigger
  const triggerPickMusic = () => {
    fileInputRef.current?.click();
  };

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      resetInactivityTimer();
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'ArrowRight') {
        audioEngine.skip(5);
      } else if (e.code === 'ArrowLeft') {
        audioEngine.skip(-5);
      } else if (e.code === 'KeyM') {
        toggleMute();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isMuted, volume, resetInactivityTimer]);

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = () => {
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleAddFiles(e.dataTransfer.files);
    }
  };

  return (
    <div
      className="fixed inset-0 w-full h-full bg-[#07080E] text-white overflow-hidden font-['Cairo',sans-serif] select-none"
      dir="rtl"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            handleAddFiles(e.target.files);
          }
        }}
      />

      {/* Drag & Drop Overlay */}
      {isDraggingOver && (
        <div
          className="fixed inset-0 z-50 bg-[#090B12]/90 backdrop-blur-md flex flex-col items-center justify-center border-4 border-dashed rounded-3xl m-4 pointer-events-none"
          style={{ borderColor: activeColorOne }}
        >
          <Upload className="w-16 h-16 animate-bounce mb-4" style={{ color: activeColorOne }} />
          <h2 className="text-2xl font-black text-white">أفلت الملفات الصوتية هنا</h2>
          <p className="text-sm text-white/60 mt-1">سيتم تشغيلها وتطبيق موجات Avee فوراً</p>
        </div>
      )}

      {/* Top App Bar (Floats over full-screen visualizer, slides up/down) */}
      <header
        onClick={(e) => e.stopPropagation()}
        className={`fixed top-0 inset-x-0 z-30 w-full px-4 sm:px-8 py-3.5 flex items-center justify-between transition-all duration-500 ease-in-out bg-gradient-to-b from-black/85 via-black/45 to-transparent ${
          isControlsVisible
            ? 'translate-y-0 opacity-100'
            : '-translate-y-full opacity-0 pointer-events-none'
        }`}
      >
        {/* Left Action (Playlist) */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsPlaylistOpen(true);
          }}
          className="p-2.5 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors flex items-center gap-1.5 cursor-pointer bg-[#121520]/80 backdrop-blur-md border border-white/5"
          title="قائمة المقاطع"
        >
          <ListMusic className="w-5 h-5" />
          <span className="hidden sm:inline text-xs font-semibold">المقاطع ({playlist.length})</span>
        </button>

        {/* Center Title: 'الموسيقى' */}
        <div className="flex flex-col items-center">
          <h1
            className="text-2xl sm:text-3xl font-black tracking-widest uppercase transition-all duration-300"
            style={{
              textShadow: `0 0 20px ${activeColorOne}80, 0 0 40px ${activeColorTwo}40`,
            }}
          >
            الموسيقى
          </h1>
          <div className="flex items-center gap-1.5 text-[10px] text-white/50 tracking-wider font-mono">
            <span>Avee Visualizer</span>
            <span>·</span>
            <span style={{ color: activeColorOne }}>
              {settings.colorMode === 'custom' ? 'ألوان مخصصة' : currentPalette.name}
            </span>
          </div>
        </div>

        {/* Right Actions: Export Video, Style Switcher, Palette & Settings */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Avee Video Export Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsVideoExportOpen(true);
            }}
            className="p-2.5 rounded-full text-white/80 hover:text-white transition-all cursor-pointer relative group bg-[#121520]/80 backdrop-blur-md border border-white/10 shadow-lg hover:border-cyan-400/40"
            title="تصدير فيديو Avee مع الصوت والموجات"
          >
            <Film className="w-5 h-5 text-cyan-400" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          </button>

          {/* Quick Wave Style Switcher */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              cycleWaveStyle();
            }}
            className="p-2.5 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer relative bg-[#121520]/80 backdrop-blur-md border border-white/5"
            title={`الشكل الحالي: ${STYLE_LABELS[settings.style]} - انقر للتبديل`}
          >
            <Waves className="w-5 h-5" style={{ color: activeColorOne }} />
          </button>

          {/* Palette button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              cyclePalette();
            }}
            className="p-2.5 rounded-full transition-colors relative group cursor-pointer bg-[#121520]/80 backdrop-blur-md border border-white/5"
            style={{ color: activeColorOne }}
            title="تبديل النمط اللوني"
          >
            <PaletteIcon className="w-5 h-5" />
            <span
              className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border border-black"
              style={{ backgroundColor: activeColorTwo }}
            />
          </button>

          {/* Settings button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsSettingsOpen(true);
            }}
            className="p-2.5 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer relative bg-[#121520]/80 backdrop-blur-md border border-white/5"
            title="إعدادات وتخصيص Avee الشاملة"
          >
            <Sliders className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Full-Screen Avee Visualizer (Fills 100% of screen edge-to-edge) */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden">
        <VisualizerCanvas
          isPlaying={isPlaying}
          colorOne={activeColorOne}
          colorTwo={activeColorTwo}
          settings={settings}
          trackTitle={currentTrack?.title || ''}
          trackArtist={currentTrack?.artist || ''}
          isControlsVisible={isControlsVisible}
          canvasRefCallback={(el) => setCanvasElement(el)}
        />
      </div>

      {/* Always Visible Floating Track Title (when controls are hidden but user chose always_visible) */}
      {settings.titleHideMode === 'always_visible' && !isControlsVisible && (
        <div className="fixed top-5 left-1/2 transform -translate-x-1/2 z-20 pointer-events-none transition-all duration-300">
          <div
            className="px-4 py-1.5 bg-black/75 backdrop-blur-md rounded-full text-center border shadow-xl flex items-center gap-2"
            style={{ borderColor: `${activeColorOne}40` }}
          >
            <Music className="w-3.5 h-3.5 shrink-0" style={{ color: activeColorOne }} />
            <span className="text-xs font-bold text-white truncate max-w-[160px] sm:max-w-[220px]">
              {currentTrack?.title}
            </span>
            <span className="text-[10px] text-white/50">·</span>
            <span className="text-[10px] font-semibold truncate max-w-[100px]" style={{ color: activeColorOne }}>
              {currentTrack?.artist}
            </span>
          </div>
        </div>
      )}

      {/* Bottom Controls Section (Floats over full-screen visualizer, auto-hides smoothly) */}
      <footer
        className={`fixed bottom-0 inset-x-0 z-30 w-full max-w-xl mx-auto px-4 sm:px-6 pb-6 pt-3 flex flex-col gap-2.5 transition-all duration-500 ease-in-out bg-gradient-to-t from-black/90 via-black/55 to-transparent ${
          isControlsVisible
            ? 'translate-y-0 opacity-100'
            : 'translate-y-full opacity-0 pointer-events-none'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Track Title and Artist Preview Bar */}
        <div className="flex items-center justify-between px-2 gap-2">
          {settings.titleHideMode !== 'hidden' ? (
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white truncate leading-tight">
                {currentTrack?.title || 'اختر أغنية للبدء'}
              </h3>
              <p className="text-[11px] text-white/50 truncate" style={{ color: activeColorOne }}>
                {currentTrack?.artist || 'مؤثرات صوتية مجانية'}
              </p>
            </div>
          ) : (
            <div className="flex-1 min-w-0 text-white/30 text-xs italic">
              تم إخفاء اسم الأغنية (يمكنك إظهاره من الزر المجاور)
            </div>
          )}

          {/* Quick Actions: Song Title Hide Mode, Lock Controls, and Manual Hide */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Title Mode Cycle Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setSettings((prev) => {
                  const modes: TitleHideMode[] = ['sync_with_bar', 'always_visible', 'hidden'];
                  const nextIdx = (modes.indexOf(prev.titleHideMode) + 1) % modes.length;
                  return { ...prev, titleHideMode: modes[nextIdx] };
                });
              }}
              className="px-2 py-1 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer flex items-center gap-1 bg-white/5 border border-white/5 text-[11px] font-sans"
              title={`سلوك اسم الأغنية: ${
                settings.titleHideMode === 'sync_with_bar'
                  ? 'يختفي مع البار'
                  : settings.titleHideMode === 'always_visible'
                  ? 'ظاهر دائماً'
                  : 'مخفي'
              } - انقر للتبديل`}
            >
              <Type className="w-3.5 h-3.5" style={{ color: activeColorOne }} />
              <span className="hidden sm:inline">
                {settings.titleHideMode === 'sync_with_bar'
                  ? 'يختفي مع البار'
                  : settings.titleHideMode === 'always_visible'
                  ? 'ظاهر دائماً'
                  : 'مخفي'}
              </span>
            </button>

            {/* Lock Controls Toggle */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setSettings((prev) => ({
                  ...prev,
                  lockControlsVisible: !prev.lockControlsVisible,
                }));
              }}
              className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                settings.lockControlsVisible
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'text-white/40 hover:text-white hover:bg-white/10 border-transparent'
              }`}
              title={
                settings.lockControlsVisible
                  ? 'الأزرار مثبتة دائماً (انقر لإعادة الاختفاء التلقائي)'
                  : 'تثبيت الأزرار دائماً ومنع اختفائها'
              }
            >
              {settings.lockControlsVisible ? (
                <Lock className="w-4 h-4" />
              ) : (
                <Unlock className="w-4 h-4" />
              )}
            </button>

            {/* Manual Hide Controls */}
            <button
              onClick={() => setIsControlsVisible(false)}
              className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="إخفاء الأزرار للدخول في وضع المشاهدة الكاملة"
            >
              <EyeOff className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Progress Slider & Timestamps */}
        <div className="w-full flex flex-col gap-1">
          <div className="relative flex items-center group">
            <input
              type="range"
              min="0"
              max={duration || currentTrack?.duration || 100}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer transition-all focus:outline-none"
              style={{
                accentColor: activeColorOne,
              }}
            />
          </div>

          <div className="flex items-center justify-between text-xs font-mono text-white/50 px-1">
            <span>{formatDuration(currentTime)}</span>
            <span>{formatDuration(duration || currentTrack?.duration || 0)}</span>
          </div>
        </div>

        {/* Primary Playback Control Row */}
        <div className="flex items-center justify-evenly py-1">
          {/* Shuffle Button */}
          <button
            onClick={() => {
              resetInactivityTimer();
              setIsShuffle((prev) => !prev);
            }}
            className="p-3 rounded-full transition-all hover:bg-white/5 active:scale-95 cursor-pointer"
            style={{ color: isShuffle ? activeColorOne : 'rgba(255, 255, 255, 0.45)' }}
            title={isShuffle ? 'التبديل العشوائي: مفعل' : 'التبديل العشوائي: معطل'}
          >
            <Shuffle className="w-5 h-5" />
          </button>

          {/* Replay 10s */}
          <button
            onClick={skipBackward10}
            className="p-3 rounded-full text-white/80 hover:text-white hover:bg-white/5 transition-all active:scale-95 cursor-pointer"
            title="رجوع 10 ثوانٍ"
          >
            <RotateCcw className="w-6 h-6" />
          </button>

          {/* Central Play/Pause Button */}
          <button
            onClick={togglePlay}
            className="w-16 h-16 rounded-full flex items-center justify-center text-black font-bold transition-all duration-300 transform active:scale-95 shadow-2xl relative group cursor-pointer"
            style={{
              background: `linear-gradient(135deg, ${activeColorOne}, ${activeColorTwo})`,
              boxShadow: `0 0 28px ${activeColorOne}55, 0 4px 15px rgba(0,0,0,0.5)`,
            }}
            title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
          >
            {isPlaying ? (
              <Pause className="w-8 h-8 fill-black text-black" />
            ) : (
              <Play className="w-8 h-8 fill-black text-black translate-x-[-2px]" />
            )}
          </button>

          {/* Forward 10s */}
          <button
            onClick={skipForward10}
            className="p-3 rounded-full text-white/80 hover:text-white hover:bg-white/5 transition-all active:scale-95 cursor-pointer"
            title="تقديم 10 ثوانٍ"
          >
            <RotateCw className="w-6 h-6" />
          </button>

          {/* Repeat Button */}
          <button
            onClick={cycleRepeat}
            className="p-3 rounded-full transition-all hover:bg-white/5 active:scale-95 relative cursor-pointer"
            style={{
              color: repeatMode !== 'off' ? activeColorOne : 'rgba(255, 255, 255, 0.45)',
            }}
            title={
              repeatMode === 'one'
                ? 'تكرار المقطع الحالي'
                : repeatMode === 'all'
                ? 'تكرار القائمة'
                : 'التكرار معطل'
            }
          >
            {repeatMode === 'one' ? (
              <Repeat1 className="w-5 h-5" />
            ) : (
              <Repeat className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Secondary Action Row: Pick Music, Export Video, Settings */}
        <div className="flex items-center gap-2 pt-1">
          {/* Export Video Button */}
          <button
            onClick={() => setIsVideoExportOpen(true)}
            className="py-3 px-3.5 rounded-xl border flex items-center justify-center gap-1.5 font-bold text-xs transition-all hover:bg-white/5 active:scale-95 shadow-sm cursor-pointer shrink-0"
            style={{
              color: activeColorOne,
              borderColor: `${activeColorOne}77`,
              backgroundColor: `${activeColorOne}12`,
            }}
            title="تصدير فيديو وموجات Avee"
          >
            <Film className="w-4 h-4" />
            <span className="hidden sm:inline">تصدير فيديو</span>
          </button>

          {/* Primary Outlined Button: "اختيار أغنية" */}
          <button
            onClick={triggerPickMusic}
            className="flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-2 font-bold text-sm transition-all hover:bg-white/5 active:scale-[0.99] shadow-sm cursor-pointer"
            style={{
              color: activeColorOne,
              borderColor: `${activeColorOne}99`,
              boxShadow: `0 0 15px ${activeColorOne}18`,
            }}
          >
            <FolderOpen className="w-4 h-4" />
            <span>اختيار أغنية</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-3 rounded-xl border border-white/10 hover:border-white/20 text-white/70 hover:text-white transition-all hover:bg-white/5 active:scale-95 flex items-center justify-center shrink-0 cursor-pointer"
            title="إعدادات المؤثرات والموجات"
          >
            <Sliders className="w-5 h-5" />
          </button>

          {/* Volume / Mute Quick Toggle */}
          <div className="hidden sm:flex items-center gap-2 px-2 py-1 bg-white/5 rounded-xl border border-white/5">
            <button
              onClick={toggleMute}
              className="p-1 text-white/60 hover:text-white transition-colors cursor-pointer"
              title={isMuted ? 'إلغاء الكتم' : 'كتم الصوت'}
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-red-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={(e) => handleVolumeChange(Number(e.target.value))}
              className="w-16 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
              style={{ accentColor: activeColorOne }}
              title="مستوى الصوت"
            />
          </div>
        </div>
      </footer>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
        currentPalette={currentPalette}
        onSelectPalette={(p) => {
          const idx = COLOR_PALETTES.findIndex((item) => item.id === p.id);
          if (idx !== -1) setPaletteIndex(idx);
        }}
      />

      {/* Video & Snapshot Export Modal */}
      <VideoExportModal
        isOpen={isVideoExportOpen}
        onClose={() => setIsVideoExportOpen(false)}
        canvas={canvasElement}
        currentTrack={currentTrack}
        currentPalette={currentPalette}
        isPlaying={isPlaying}
        onStartPlayback={togglePlay}
      />

      {/* Playlist Modal */}
      <PlaylistModal
        isOpen={isPlaylistOpen}
        onClose={() => setIsPlaylistOpen(false)}
        playlist={playlist}
        currentTrackId={currentTrack?.id || ''}
        isPlaying={isPlaying}
        onSelectTrack={(t) => {
          const idx = playlist.findIndex((p) => p.id === t.id);
          if (idx !== -1) {
            setCurrentTrackIndex(idx);
            playTrack(t, true);
          }
        }}
        onUploadFiles={handleAddFiles}
        currentPalette={{
          ...currentPalette,
          colorOne: activeColorOne,
          colorTwo: activeColorTwo,
        }}
      />
    </div>
  );
}
